# Python核心基础

## 目录

- [Python 环境搭建](#Python-环境搭建)
  - [Anaconda 包管理](#Anaconda-包管理)
  - [环境搭建和基础命令](#环境搭建和基础命令)
  - [包的管理](#包的管理)
- [python基础语法](#python基础语法)
  - [⭐标识符与命名规范](#标识符与命名规范)
    - [标识符的构成规则](#标识符的构成规则)
    - [特殊下划线含义](#特殊下划线含义)
    - [PEP 8 命名规范](#PEP-8-命名规范)
    - [保留字符 (Reserved Keywords)](#保留字符-Reserved-Keywords)
    - [代码结构](#代码结构)
  - [⭐输入和输出](#输入和输出)
  - [⭐变量 ](#变量-)
  - [⭐基础变量类型 ](#基础变量类型-)
    - [字符串 str](#字符串-str)
      - [字符串运算](#字符串运算)
      - [字符串访问（索引与切片）](#字符串访问索引与切片)
      - [关系判断 (in和not in)](#关系判断-in和not-in)
      - [格式化表达式](#格式化表达式)
      - [💫 常见API — 对字符串进行各种操作](#-常见API--对字符串进行各种操作)
    - [数字类型](#数字类型)
      - [整数 int](#整数-int)
      - [复数](#复数)
      - [浮点数 float](#浮点数-float)
      - [布尔数 bool](#布尔数-bool)
    - [复合类型](#复合类型)
      - [💛 列表\[\] list](#-列表-list)
      - [💚 元组() tuple ](#-元组-tuple-)
      - [🩵 字典{} dict ](#-字典-dict-)
      - [💜 集合set/固定集合frozenset](#-集合set固定集合frozenset)
      - [🩶 字节串 bytes/字节数组 bytearray](#-字节串-bytes字节数组-bytearray)
  - [⭐可变与不可变](#可变与不可变)
    - [不可变类型](#不可变类型)
    - [可变类型](#可变类型)
    - [二者区别](#二者区别)
  - [⭐类型判断与转换速查表](#类型判断与转换速查表)
    - [类型判断](#类型判断)
    - [类型转换](#类型转换)

# Python 环境搭建

> **为什么选择 Anaconda？**
>
> 环境管理： 使用 Anaconda，可以轻松地创建和管理多个独立的 Python 环境，比如可以安装 python2 和 python3 环境，然后实现自由切换。这对于在不同项目中使用不同的库和工具版本非常有用，以避免版本冲突。
>
> 集成工具和库： Anaconda 捆绑了许多用于数据科学、机器学习和科学计算的重要工具和库，如 NumPy、Pandas、Matplotlib、SciPy、Scikit-learn 等

#### **Anaconda 包管理**

C:\Users\\<用户名>\\.condarc  **→**  .condarc 文件用于定义 Conda 的包管理行为

```yaml title="condarc 文件内容解释"
channels:   # 指定Conda查找软件包的下载源（镜像源）
  - defaults
envs_dirs:  # 指定Conda虚拟环境的存储路径
  # 默认情况下，Conda会在Anaconda安装目录下的envs文件夹中创建环境（如E:\Anaconda\envs）
  - E:\\Anaconda\\envs
pkgs_dirs:  # 指定Conda下载的缓存包（.tar.gz文件）的存储路径
  # 所有通过conda install安装的包会先下载到pkgs目录，再解压到具体环境中
  - E:\\Anaconda\\pkgs
```


输出显示你添加的镜像源：conda config --show channels

添加镜像：conda config --add channels <镜像地址>

清除原有配置：conda config --remove-key channels

#### 环境搭建和基础命令

查看conda版本：conda --version

创建新的 Conda 环境 ：conda create -n python\_env python==3.12

```bash title="创建环境"
conda create --name <环境名>    # 创建指定名称的环境（默认使用当前conda的Python版本）
conda create--name <环境名> python==3.9   # 创建指定Python版本的环境
conda create --name <环境名> numpy pandas python==3.10     # 创建包含指定包的环境

```


conda create -p D:\anaconda3\envs\ai python=3.12

删除环境：conda  remove —name <环境名> —all

查看环境

```bash title="查看环境"
conda env list      # 列出所有已创建的环境
conda info --envs      # 或
# 查看当前激活的环境
echo $CONDA_DEFAULT_ENV  # Linux/Mac
echo %CONDA_DEFAULT_ENV%  # Windows
```


conda create —help : 查看帮助

激活/切换环境

```python title="激活 / 切换环境"
conda activate <环境名>   # 激活指定环境 （Linux/Mac） 
activate <环境名>   # 激活指定环境 （Windows cmd） 
 # 激活指定环境（Windows PowerShell） 
conda activate <环境名>  # 需先执行 conda init powershell
```


退出当前环境（回到base环境）：conda deactivate

其他基本命令：

cls 清屏

dir 查看目录文件

#### 包的管理

**安装**

使用conda install安装：conda install opencv 【推荐】

使用pip install安装：pip install opencv-python

指定镜像安装：pip install opencv-python -i [https://pypi.tuna.tsinghua.edu.cn/simple](https://pypi.tuna.tsinghua.edu.cn/simple "https://pypi.tuna.tsinghua.edu.cn/simple")

**卸载**

conda uninstall卸载：conda uninstall opencv 【推荐，会自动处理依赖关系】

pip uninstall只卸载通过pip安装的包：pip uninstall opencv-python

**包的版本**

查看可用的包版本：conda search pandas

指定安装版本：conda install pandas==2.2.2

# python基础语法

> **注释**
>
> ctrl + / ：大量注释
>
> \# ：单行注释
>
> 三个单引号 ''' 或者三个双引号 """ 将注释括起来：多行注释用

## ⭐标识符与命名规范

在 Python 中，标识符是用于给变量、函数、类、模块等命名的名字

#### 标识符的构成规则

组成字符：只能包含字母（a-z, A-Z）、数字（0-9）和下划线（ \_）

开头限制：不能以数字开头

✅ 正确：user1, \_temp, data\_2026

❌ 错误：1user, 9data

#### 特殊下划线含义

Python 对以下划线开头的标识符有特殊约定：

**单下划线开头 (**\_foo **)**：

表示"受保护"或"内部使用"的成员

虽然技术上可以访问，但这是一种约定，告诉开发者"不要直接在外部调用"

在使用 from module import \* 时，这类名称不会被导入

**双下划线开头 (**\_\_foo **)**：

表示类的私有成员

Python 会对其进行"名称改写"(Name Mangling)，例如在类 MyClass 中定义 \_\_secret，实际存储名为\_MyClass\_\_secret，以此避免子类命名冲突

**双下划线开头且结尾 (**\_\_foo\_\_​**)**：

这是Python的魔术方法(Magic Methods)或系统专用标识

例如：\_\_init\_\_(构造函数), \_\_str\_\_(字符串表示)。用户自定义变量应**避免**使用这种格式

#### PEP 8 命名规范

为了代码的可读性，Python 社区遵循 PEP 8风格指南：

![](image/image_UoQ9HsgLJY.png)

#### 保留字符 (Reserved Keywords)

保留字(关键字)是Python语言内部使用的单词，不能用作变量名、函数名或类名

**特点**：所有关键字均为全小写（除了True, False, None这三个内置常量）

**常见关键字列表**：

流程控制：`if, else, elif, for, while, break, continue, pass`

逻辑运算：`and, or, not, is, in`

定义结构：`def, class, lambda, yield, return`

异常处理：`try, except, finally, raise, assert`

其他：`import, from, global, del, with, as` 

(注：exec 和 print 在 Python 2 是关键字，但在 Python 3中 print 是函数，exec 是内置函数，不再是严格的关键字，但建议仍避免用作变量名)

**检查方法**：在 Python 中输入以下代码，查看当前版本的所有关键字

```python title="检查方法"
import keyword
print(keyword.kwlist)
```


#### 代码结构

**行与缩进**&#x20;

Python 与其他语言(C++, Java)最大的区别：Python使用缩进来划分代码块，而不是大括号 {}

**缩进规则**

强制性：同一层级的代码块必须拥有完全相同的缩进量

空白数量：可以是空格或 Tab，但官方推荐使用**4个空格**作为一个缩进层级

混合禁忌：严禁在同一文件中混用 Tab 和空格来缩进，否则会报错TabError或IndentationError

**多行语句**

Python 通常一行写一条语句，但可以通过以下方式换行：

显式换行符 (\\)：当一行代码太长时，使用反斜杠 \ 连接到下一行

```python title="显示换行符"
total = item_one + \
        item_two + \
        item_three
```


🟡 隐式换行 ：如果语句中包含括号(), \[], {}，则不需要\，可以直接换行。这在处理长列表或函数参数时非常常用

```python title="隐式换行"
days = [
    'Monday', 'Tuesday', 'Wednesday',
    'Thursday', 'Friday'
]
```


## ⭐输入和输出

**输入**：Python 中最常用的输入函数是`input()`，用于获取用户从键盘输入的内容

```python title="示例"
变量名 = input("提示信息")
# input()函数会暂停程序执行，等待用户在控制台输入内容，用户输入完成并按下回车键后
# input()函数会将用户输入的内容以字符串的形式返回，并赋值给指定的变量。
name = input("请输入你的姓名：")
print(f"你好，{name}！")

```


如果需要数字，必须手动转换

```python title="数据类型转换"
age_str = input("请输入年龄：")
age = int(age_str)  # 转换为整数
```


**输出：** Python 中最常用的输出方式是使用`print()`函数，用于将数据输出到控制台

```python title="示例"
print(输出内容)
print("Hello, World!") # 输出字符串
message = "Python真有趣！"
print(message) #输出变量

```


```python title="格式化输出 (f-string) —— 推荐方式 (Python 3.6+)"
info = "你好"
print(f"{info}世界")  # 输出：你好世界
```


```python title="拼接与分隔"
print(info, "世界")      # 输出：你好 世界 (默认用空格分隔)
print(info + "世界")     # 输出：你好世界 (字符串直接拼接，无空格)
```


```python title="取消换行"
# 默认print结束后会换行，通过end参数可以修改结束符 
print(info, end="世界")    # 输出：你好世界 (光标停在'界'后面，不换行)
```


## ⭐变量&#x20;

变量是用赋值语句创建，用来绑定一个数据的有名对象

**变量赋值**

```python title="语法"
变量名 = 数字类型
变量名 = 表达式        # one_hundred = 99 + 1
变量名1 = 变量名2 = 变量名3  = 数字类型        # a=b=c=200
变量名1, 变量名2, 变量名3  = 数字类型1, 数字类型2, 数字类型3    # a,b = 100,200
counter = 100          # 整型变量
miles   = 1000.0       # 浮点型变量
name    = "hqyj"     # 字符串

```


1. 第一次赋值是创建变量，同时绑定表达式执行结果
2. 后续再赋值，会改变原有变量的绑定关系
3. 变量本身是没有类型，它绑定的对象才有类型
4. 变量在使用之前，必须先进行赋值
5. 变量赋值是一个自右向左的运算，将=右边表达式结果赋值给变量

## \*\*⭐\*\*​**基础变量类型**&#x20;

🔗 官方文档：[https://docs.python.org/zh-cn/3.13/library/stdtypes.html#sequence-types-list-tuple-range](https://docs.python.org/zh-cn/3.13/library/stdtypes.html#sequence-types-list-tuple-range "https://docs.python.org/zh-cn/3.13/library/stdtypes.html#sequence-types-list-tuple-range")

### **字符串 str**

```python title="使用反斜杠\对字符进行转义"
\'    代表单引号
\"    代表双引号
\n    代表换行符
\\    代表反斜杠
\t    代表缩进
```


```python title="字符串前加r表示原始字符串，不转义；"
r'c:\window\user\data'
```


#### **字符串运算**

```python title="字符串连接（+ 运算符）"
s1 = "Hello"
s2 = "World"
result = s1 + " " + s2  # 拼接时可加入空格分隔
print(result)  # 输出："Hello World"

 只能连接字符串类型，不能直接与数字、列表等其他类型连接（需先通过 str() 转换）： 
# 错误示例（类型不匹配）
# print("年龄：" + 18)   # 报错：TypeError 
print("年龄：" + str(18))  # 正确：先转换为字符串，输出"年龄：18"
```


当多个字符串字面值相邻摆放时，Python 会自动将它们合并，无需显式使用 +

```python title="字符串字面值自动合并"
# 自动合并相邻字符串字面值
s = "Py" "thon"  # 等价于 "Python"
print(s)  # 输出："Python"
# 拆分长字符串（代码换行时更清晰）
long_str = "这是一段非常长的字符串，" "可以拆分成多部分，" "Python自动合并它们"
print(long_str)  # 输出："这是一段非常长的字符串，可以拆分成多部分，Python自动合并它们"
```


⚠️ 注意：变量与字面值相邻不会自动合并，例如 `s = "Py" + ``var` 必须用+连接

```python title="字符串重复（* 运算符）"
*右侧必须是整数（正整数表示重复次数，0 或负数返回空字符串） 
print("abc" * 3)  # 重复3次，输出："abcabcabc"
print("---" * 10)  # 输出："------------------------------"（30个减号）
print("test" * 0)  # 输出：""（空字符串）
print("x" * -2)    # 输出：""（负数也返回空字符串）
```


#### **字符串访问（索引与切片）**

字符串是有序序列，每个字符有固定位置(索引)，可通过索引或切片精确访问部分内容

**索引规则**：字符串\[索引值]

从左到右：索引从0开始（第一个字符索引为0，第二个为1）

从右到左：支持负数索引（最后一个字符索引为-1，倒数第二个为-2）

```python title="索引值不能超出字符串长度范围，否则会报错 IndexError"
s = "python"
print(s[0])   # 第一个字符，输出："p"
print(s[2])   # 第三个字符，输出："t"
print(s[-1])  # 最后一个字符，输出："n"
print(s[-3])  # 倒数第三个字符，输出："h"
```


切片：从字符串中截取连续的一部分，返回一个新字符串（原字符串不变，因字符串不可变）

**切片语法：** 字符串\[start : end : step]

start：起始索引（包含该位置字符，默认从0开始）

end：结束索引（不包含该位置字符，默认到字符串末尾）

step：步长（每次移动的间隔，默认1；为负数时表示反向截取）

```python title="示例解析"
s = "huaqyj"
# 案例1：s[:2] → 省略start（默认0），end=2，step=1
print(s[:2])  # 截取索引0到1的字符，输出："hu"
s = "huaqingyunajian"
# 案例2：s[1:5:2] → start=1，end=5，step=2（间隔1个字符取一次）
# 索引1: 'u'，索引3: 'q'（跳过索引2），end=5不包含索引5 → 结果："uq"
print(s[1:5:2])  # 输出："uq"
# 案例3： s[::-1]  → start和end省略（默认从头到尾）， step=-1（反向截取） 
print(s[::-1])  # 反转字符串，输出："naijunygnaiquh"
```


#### **关系判断**\*\* (in和not in\*\*)

判断一个字符串是否包含另一个子字符串（返回布尔值True或False）

```python title="示例"
s = "Python is a programming language"
# 判断"Python"是否在s中
print("Python" in s)  # 输出：True
# 判断"java"是否在s中
print("java" in s)    # 输出：False
# 判断"language"是否不在s中
print("language" not in s)  # 输出：False（因包含，所以"not in"为False）
```


#### **格式化表达式**

**占位符** —— 生成具有一定格式的字符串

![](image/image_X_ufqtdCFe.png)

```python title="示例代码"
fmt = """
甲方:_____ %s _____
乙方:_____ %s _____
   ....... 金额:_ %d __
"""
s = fmt % ("小王", '华清', 10000)
b = fmt % ("小红", '华清', 10000)
print(s)
```


![](image/image_y2zULW3zhs.png)

```python title="示例代码2"
print("------%F------" % 3.1415)
print("------%g------" % 3.1415)
print("------%e------" % 3.1415)
print("------%e------" % 31.415)
print("------%g------" % 3141523274812374281342374324.23748123742183472)
# 按照指定的宽度打印，并保留指定的小数位数
print("------%30.2f------" % 3141523274814.23748123742183472)
print("------%30.2f------" % 3144814.3472)
print("------ %-30.2f ------" % 14)
```


![](image/image_06IMaLyu2L.png.mark.png)

**f-string 格式化字符串**以$f$开头，字符串中的表达式用 {} 包起来

```python title=" f-string（格式化字符串字面值）"
x = 1
y = 2.3 

 # f'{x+1}'中，{x+1}是一个表达式，会先计算x+1（结果为2），再将结果嵌入字符串中 
print(f'{x+1}')   #2
x = 1

 #   f'{x+1=}'中， =是f-string的特殊语法 ，作用是同时显示表达式本身和计算结果 
print(f'{x+1=}')   #x+1=2  

d = 12
 # {d}直接将变量d的值(12)嵌入字符串'abc'中，拼接后得到'abc12' 
print(f'abc{d}') # 其中的{}中为变量或表达式

 # 可以使用:对变量进一步格式化 
pi = 3.1415
# {pi:.2f}中， : 是格式化修饰符的分隔符, .2f 表示将浮点数保留2位小数
print(f'{pi:.2f}') # 3.14
```


#### 💫 **常见API — 对字符串进行各种操作**

常见API，详见文档： [https://docs.python.org/zh-cn/3/library/stdtypes.html#string-methods](https://docs.python.org/zh-cn/3/library/stdtypes.html#string-methods "https://docs.python.org/zh-cn/3/library/stdtypes.html#string-methods")

方法的调用语法：对象.方法名(参数)

```python title="示例"
1. str.lower(): 将字符串转换为小写 
text = "Hello, World!"
print(text.lower())  # 输出: hello, world!

 2. str.upper(): 将字符串转换为大写 
text = "Hello, World!"
print(text.upper())  # 输出: HELLO, WORLD!

 3. str.strip(): 移除字符串两端的空白字符 
text = "   Hello, World!   "
print(text.strip())  # 输出: Hello, World!

 4. str.split(): 将字符串拆分为列表 
text = "Hello,   World!"
print(text.split())  # 输出: [' Hello, ', ' World! ']
text = "Hello,World!"
print(text.split(','))  # 输出: ['Hello', 'World!']

 5. str.join(): 将列表中的字符串连接为一个字符串 
words = ['Hello', 'World']
print("   ".join(words))  # 输出: Hello   World
words = ['apple', 'banana', 'cherry']
print(" ,  ".join(words))  # 输出: apple ,  banana ,  cherry

 6. str.replace(): 替换字符串中的子字符串 
text = "Hello, World!"
print(text.replace("World", "Python"))  # 输出: Hello, Python!

 7. str.find(): 查找子字符串，返回第一次出现的位置 
text = "Hello,   World!"
print(text.find("World"))  # 输出: 7
print(text.find("Python"))  # 输出: -1（如果未找到则返回 -1）

 8. str.startswith(): 检查字符串是否以指定子字符串开头 
text = "Hello, World!"
print(text.startswith("Hello"))  # 输出: True
print(text.startswith("World"))  # 输出: False

 9. str.endswith(): 检查字符串是否以指定子字符串结尾 
text = "Hello, World!"
print(text.endswith("World!"))  # 输出: True
print(text.endswith("Hello"))  # 输出: False

 10. str.isdigit(): 检查字符串是否只包含数字字符 
text1 = "12345"
text2 = "12345abc"
print(text1.isdigit())  # 输出: True
print(text2.isdigit())  # 输出: False

 11. str.isalpha(): 检查字符串是否只包含字母字符 
text1 = "Hello"
text2 = "Hello123"
print(text1.isalpha())  # 输出: True
print(text2.isalpha())  # 输出: False

 12. str.isalnum(): 检查字符串是否只包含字母和数字字符 
text1 = "Hello123"
text2 = "Hello 123"
print(text1.isalnum())  # 输出: True
print(text2.isalnum())  # 输出: False

 13. str.title(): 将字符串中的每个单词的首字母转换为大写 
text = "hello, world!"
print(text.title())  # 输出: Hello, World!

 14. str.capitalize(): 将字符串的首字母转换为大写 
text = "hello, world!"
print(text.capitalize())  # 输出: Hello, world!

 15. str.count(): 计算子字符串在字符串中出现的次数 
text = "Hello, World! Hello, Python!"
print(text.count("Hello"))  # 输出: 2
print(text.count("Python"))  # 输出: 1

 16. str.format(): 格式化字符串 
name = "John"
age = 30
print("My name is  {}  and I am  {}  years old." .format(name, age) )
# 输出: My name is John and I am 30 years old.
print(f"My name is  {name}  and I am  {age}  years old.")
# 输出: My name is John and I am 30 years old. (使用 f-string)
```


### **数字类型**

#### **整数 int**

```python title="int"
# 十进制的写法：直接书写数字，无需前缀,没有特殊前缀,是Python中默认的数字表示方式
100        0         -5
# 二进制的写法：0b开头,后跟0~1
0b1101
# 八进制的写法：0o开头,后跟0~7
0o777   等于  0b111111111   等于 511
# 十六进制的写法：0x开头,后跟0~9,a-f,A-F
0xA1B2C3D4
```


进制转换工具（Python 内置函数）

| 函数          | 作用                       | 示例               |
| ----------- | ------------------------ | ---------------- |
| bin(x)      | 将数字转换为二进制字符串（带\`0b\`前缀）  | bin(10)→'0b1010' |
| oct(x)      | 将数字转换为八进制字符串（带\`0o\`前缀）  | oct(10)→'0o12'   |
| hex(x)      | 将数字转换为十六进制字符串（带\`0x\`前缀） | hex(10)→'0xa'    |
| int(x,base) | 将指定进制的字符串转换为十进制整数        | int(0b1010,2)→10 |

#### **复数**

通过 a + bj 的形式直接定义复数，虚数部分必须包含j或J

```python title="复数转换函数：complex()"
z1 = 3 + 4j  # 实数部分3，虚数部分4
z2 = -2.5 + 1j  # 实数部分-2.5，虚数部分1
print(complex(5))       # 输出：(5+0j)  → 实数5，虚数0
print(complex(3.14))    # 输出：(3.14+0j)  → 浮点数转换
print(complex("10"))    # 输出：(10+0j)  → 字符串转换（仅含数字）
print(complex(2, 3))    # 输出：(2+3j)  → 实数2，虚数3
print(complex(0, 5))    # 输出：5j  → 实数0，虚数5（可简写）
print(complex(3.5, -2)) # 输出：(3.5-2j)  → 虚数部分为负数

```


#### **浮点数 float**

```python title="float"
# 小数写法
3.14         0.14       .14         3.0       3.      0.0
# 科学计数法
6.18E-1     # 等同于 0.618   
2.9979E8     # 等同于 299790000.0
```


#### **布尔数 bool**

类型转换使用bool()方法，非0都是True

0、0.0、-0.0、空字符串、空列表、空字典、空集合、空元组、None等都是False；

```python title="布尔值转换函数：bool(x)"
# 返回 False 的情况
print(bool(0))         # False（整数0）
print(bool(0.0))       # False（浮点数0）
print(bool(""))        # False（空字符串）
print(bool([]))        # False（空列表）
print(bool(None))      # False（空值）

# 返回 True 的情况
print(bool(1))         # True（非零整数）
print(bool(-3.14))     # True（非零浮点数）
print(bool("abc"))     # True（非空字符串）
print(bool([0]))       # True（非空列表，即使元素为0）
print(bool(2+3j))      # True（复数非零）
```


math函数：[https://docs.python.org/zh-cn/3.12/library/math.html](https://docs.python.org/zh-cn/3.12/library/math.html "https://docs.python.org/zh-cn/3.12/library/math.html")

### **复合类型**

&#x20;Python 支持多种复合数据类型，可将不同值组合在一起

#### 💛 **列表\[] list**

列表内的数据有先后顺序关系，列表是可变的容器

```python title="列表创建"
L = []     # 创建一个空的列表
L = ['北京', '上海', '广州', '西安']  # 创建一个含有4个字符串的列表
L = [1, 'Two', 3.14, True, False, None]
L = [1, 2, [3.1, 3.2], 4]   #  含有四个元素的列表，第三个元素是列表
L2 = [
  ['姓名','语文成绩','数学成绩'],
  ['小王', 90, 100],
  ['牛犇', 59, 26]
]
```


```python title="构造函数list"
L = list()          # 创建一个空的列表，等同于[]：L = []
L = list("ABC")     # 用可迭代对象创建一个列表：L = ['A', 'B', 'C']
L = list(range(5))  # L = [0, 1, 2, 3, 4]
```


列表list同字符串str都是序列, 他们的运算规则基本相同

```python title="+ 用于拼接列表"
[1, 2, 3] + [4, 5, 6]   # [1, 2, 3, 4, 5, 6]
```


```python title="+= 追加（列表 += 可迭代对象）"
L = [1, 2, 3]
L += [4, 5]         # L = [1, 2, 3, 4, 5]
L = [1, 2, 3]
L += "ABC"          # L = [1, 2, 3, 'A', 'B', 'C']
L += range(2)       # L = [1, 2, 3, 0, 1]
```


```python title="* 用于生产重复的列表"
[1, 2] * 3    # [1, 2, 1, 2, 1, 2]
L = [5, 6]
L *= 3        # L = [5, 6, 5, 6, 5, 6]
```


```python title="== 、!= 用于比较"
[1, 2, 3] == [1, 2, 3]    # True
[1, 2, 3] != [3, 2, 1]    # True

```


```python title="in 、not in 用于判断一个数据元素是否在列表中"
"hello" in [1, "hello", 'world']
True
'红楼梦'  in ['三国演义', '西游记']
False
```


**列表访问**：与字符串的索引一样，列表索引从 0 开始，第二个索引是 1，依此类推

![](image/image_2ngkTpkIsi.png)

![](image/image_8fEdzH8FoW.png)

**切片**：列表\[开始索引b : 终止索引e :  步长s]

![](image/image_aKQ3a89AXX.png)

**列表操作** — 增,删,改,查(就是列表访问)

| 方法名(L代表列表)           | 说明                            |
| -------------------- | ----------------------------- |
| L.append(x)          | 向列表的末尾追加单个数据                  |
| L.insert(index, obj) | 将某个数据obj 插入到 index这个索引位置的数据之前 |
| L.extend(可迭代对象)      | 等同于: L += 可迭代对象               |

```python title="添加数据"
mylist1 = [1, 3, 4]             
mylist1.append(5)               # mylist1 = [1, 3, 4, 5]
mylist1.insert(1, 2)            # mylist1 = [1, 2, 3, 4, 5]
mylist1.extend(range(6, 10))    # mylist1 = [1, 2, 3, 4, 5, 6, 7, 8, 9]
```


用索引赋值可以改变列表内的数据：列表\[整数表达式] = 表达式

```python title="修改数据"
mylist2 = [1, 1.99, 3]   # 把1.99 改为2
mylist2[1] = 2    # mylist2 = [1, 2, 3]
```


| 方法          | 说明                                |
| ----------- | --------------------------------- |
| L.remove(x) | 从列表L中删除第一次出现在列表中的数据元素，如果x不存在则报错   |
| L.pop()     | 根据索引删除元素，并返回该元素。若不提供索引，默认删除最后一个元素 |
| L.clear()   | 清空列表                              |

```python title="删除数据"
L = [1, 2, 3, 4, 2, 2, 3, 4]
L.remove(3)    #  L = [1, 2, 4, 2, 2, 3, 4]
L.remove(3)    #  L = [1, 2, 4, 2, 2, 4]
L.remove(3)    #  报错了
L.clear()      #  L = []
```


del 变量名 →  删除变量，同时解除变量绑定的对象

del 列表\[整数表达式]

```python title="del 语句删除指定位置的数据元素"
L = ['张飞', '赵云', '鲁班7号', '孙悟空']
del L[2]    # L = ['张飞', '赵云', '孙悟空']
del L       # 删除 L 变量

```


通用操作：[https://docs.python.org/zh-cn/3.13/library/stdtypes.html#common-sequence-operations](https://docs.python.org/zh-cn/3.13/library/stdtypes.html#common-sequence-operations "https://docs.python.org/zh-cn/3.13/library/stdtypes.html#common-sequence-operations")

可变容器操作：[https://docs.python.org/zh-cn/3.13/library/stdtypes.html#mutable-sequence-types](https://docs.python.org/zh-cn/3.13/library/stdtypes.html#mutable-sequence-types "https://docs.python.org/zh-cn/3.13/library/stdtypes.html#mutable-sequence-types")

#### **💚 元组() tuple**&#x20;

元组使用小括号 ( )，虽然圆括号可有可无

元组的元素多为异质的，不可变的(immutable)，通过解包或索引访问

列表的元素多为同质的，可变的(mutable)，可迭代访问

**元组的特点**

有序：元素有固定的顺序，可以通过索引访问（如 tup1\[0]）

异构：元组中可以包含不同类型的元素（如 tup1 中既有整数 12 也有浮点数 34.56）

不可变：这是元组与列表(List)最大的区别。一旦创建，不能修改、添加或删除其中的元素（例如tup1\[0] = 99会报错）

**元组创建**

```python title="创建元组的字面值 -- 用小括号() 括起来，单个元素括起来后加逗号来区分单个元素还是元组"
t = ()         # 空元组
t = (100,)      # 一个元素的元组，在元素后面添加逗号，否则括号会被当作运算符 
t = 100,       # 一个元素的元组
t = (1, 2, 3)  # 含有三个数据元素的元组
t = ( 'zzl', 2004) # 存放不同类型的元组
t = 1, 2, 3    # 含有三个数据元素的元组
```


```python title="创建元组的函数 tuple"
t = tuple()          # t = ()
t = tuple(range(5))  # t = (0, 1, 2, 3, 4)
```


**元组操作** — 元组是不可变容器，相对来讲操作少一些

元组中的元素值是不允许删除的，但可以用del删除元组

```python title="删除元组"
tup = ('openAI', 'zzl', 100, 200) 
print (tup)
del tup
print (tup)    #name 'tup' is not defined
```


元组的元素访问可以像列表一样通过下标、切割等方式去访问。

```python title="查看元组"
tup1 = ('python', 'zzl', 100, 200)
tup2 = (1, 2, 3, 4, 5, 6, 7 )
print (tup1[0])    # python
print (tup2[1:5])  # (2, 3, 4, 5)
print (tup2[:4])   # (1, 2, 3, 4)
print (tup2[2:])   # (3, 4, 5, 6, 7)
```


序列解包：解构赋值，左侧变量与右侧序列元素的数量应相等

```python title="解包技能"
fruit = ('apple', 'pear', 'peach')
f1, f2, f3 = fruit
print(f1, f2, f3)
```


**元组运算**

![](image/image_OK7_njE2d2.png)

```python title="元组中的元素值是不允许修改的，但可以对元组进行连接组合"
tup1 = (12, 34.56)
tup2 = ('abc', 'xyz') 
# 虽然单个元组不可变，但+运算符可以将两个元组连接起来，生成一个全新的元组
tup3 = tup1 + tup2  
print (tup3)       # (12, 34.56, 'abc', 'xyz')

t = (1, 2, 3) + (4, 5, 6)
# 1.计算右侧表达式：t+(7,8,9)，这会创建一个新的元组（原t的内容加上7,8,9）
# 2.将这个新元组的引用重新赋值给变量名t
# 3.原来的那个t指向的元组如果没有其他变量引用，会被垃圾回收
 对于元组，+=本质上是“创建新元组->更新变量指向”，而不是原地修改 
t += (7, 8, 9)     # 等同于 t = t + (7, 8, 9)

# 元组乘以一个整数N，会将元组内的元素重复N次，生成一个新元组
t = t * 2
t *= 2

# 检查某个元素是否存在于元组中
5 in t
```


**元组不可变**

```python title="不可变指的是变量指向的内存中的内容不可变，但是变量的指向是可以改变的"
tup = (1, 2, 3, 4, 5, 6, 7)
tup[1] = 100
print(tup)    # 报错'tuple' object does not support item assignment
```


```python title="变量是可以重新赋值的"
tup1 = (12, 34.56)
tup1 = (12, 100)

```


**元组常用API**

通用操作：[https://docs.python.org/zh-cn/3.13/library/stdtypes.html#common-sequence-operations](https://docs.python.org/zh-cn/3.13/library/stdtypes.html#common-sequence-operations "https://docs.python.org/zh-cn/3.13/library/stdtypes.html#common-sequence-operations")

Python元组包含了以下内置函数

| 方法          | 描述         |
| ----------- | ---------- |
| len(tuple)  | 返回元组中元素个数  |
| max(tuple)  | 返回元组中元素最大值 |
| min(tuple)  | 返回元组中元素最小值 |
| tuple(list) | 将列表转换为元组   |

元组常用的方法

| 运算                           | 结果                                                  |
| ---------------------------- | --------------------------------------------------- |
| s.index(x\\\[, i \\\[, j] ]) | \*x\* 在 \*s\* 中首次出现项的索引号（索引号在 \*i\* 或其后且在 \*j\* 之前） |
| s.count(x)                   | \*x\* 在 \*s\* 中出现的总次数                               |

```python title="s.index(x[, i[, j]]) —— 查找索引"
# i：开始搜索的索引（包含）
# j：结束搜索的索引（不包含）
# 注意：如果找不到元素，会抛出 ValueError 错误
data = (10, 20, 30, 20, 40, 20)
# 普通查找：找到第一个 20
print(data.index(20))         # 输出: 1

# 进阶查找：从索引 2 开始找 20 (跳过第一个)
# 语法: index(元素, 起始位置)
print(data.index(20, 2))      # 输出: 3 (找到了第二个 20)

# 高级查找：在索引 2 到 5 之间找 20
# 语法: index(元素, 起始位置, 结束位置)
# 范围是 [2, 5)，即只看索引 2, 3, 4 的元素 (30, 20, 40)
print(data.index(20, 2, 5))   # 输出: 3
```


```python title="s.count(x) —— 统计次数"
# 返回值：整数，如果没找到，返回0（不会报错）
scores = (85, 90, 85, 78, 90, 85, 100)
# 统计得 85 分的人数
count_85 = scores.count(85)
print(f"得 85 分的有 {count_85} 人")   # 输出: 3
# 统计得 60 分的人数 (不存在)
count_60 = scores.count(60)
print(f"得 60 分的有 {count_60} 人")   # 输出: 0
```


#### **🩵 字典{} dict**&#x20;

字典是可变容器，可存储任意类型对象

字典以键(key)-值(value)对的形式进行映射，键值对用冒号分割，对之间用逗号分割：

d = {key1: value1,  key2: value2,  key3: value3 }

字典的数据是无序的

字典的键只能用不可变类型，且不能重复

字典的数据用键进行索引，不能用整数进行索引

**字典创建**

```python title="创建字典的字面值"
# 初始化一个没有任何内容的字典
d = {}    # 创建空字典
d = {'name': "weimingze", "age": 35}
# 字典的值可以是可变对象
d = {'a': [1, 2, 3]}
# 字典的值也可以是另一个字典，用于表示层级结构或复杂对象
d = {'b': {"bb": 222}}
# 键不仅可以是字符串，还可以是数字（整数、浮点数）
d = {1:'壹', 2:'贰', 5:'伍'}
# 元组可以作为字典的键，字典的键必须是“不可变类型” (Immutable)
d = {(1, 2, 3):'壹贰伍'}
```


```python title="以下写法会存在问题"
d = {'a': 1, 'b': 2, 'a': 3}  # 字典的键不能重复 d = {'a': 3, 'b': 2}  
# 列表作为键引发的错误
d = {[1, 2, 3]: 'a'}          # TypeError: unhashable type: 'list'
# 列表是可变类型（Mutable），其哈希值在创建后可能改变（如 append()）
 # 字典要求键的哈希值在生命周期内保持稳定
```


字典的构造需满足"键值对可解析"原则，即传入的参数必须能被解析为"键：值"的形式

```python title="字典的创建函数 dict()"
d = dict()   # d = {}
d = dict([("name", "小王"), ("age", 35)])  # {'name': '小王', 'age': 35}
d = dict(a=1, b=2, c=3)    # {'a':1, 'b':2, 'c':3}
d = dict([1, 2, 3, 4])  # 错
# 传入的列表 [1, 2, 3, 4] 是单元素序列（每个元素长度为 1）
 # dict 要求可迭代对象的每个元素必须是长度为 2 的序列（如元组、列表）
```


**字典操作**

增加或修改：字典\[键key] = 表达式

键不存在, 就添加；键存在, 会改变键对应的值

```python title="示例"
d = {}
d['name'] = 'tarena'  # 添加键值对
d['age'] = 18         # d = {'name': 'tarena', 'age': 18}
d['age'] = 19         # 改变键对应的值
```


字典的键索引：字典\[键key]

```python title="示例"
d = {'one': 1, 'two': 2}
print(d['two'])   # 2
# 如果键不存在，会报错
mydic = {'Name': 'zzl', 'Age': 20, 'Class': 'First'} 
print (mydic['Alice'])    # KeyError: 'Alice'

```


&#x20;in/not in：

in用于判断一个键是否存在于字典中,存在返回True, 否则返回False

```python title="示例"
d = dict(a=1, b=2)         # d = {'a': 1, 'b': 2}
print('a' in d)            # True  
print(1 in d)              # False
print('hello' not in d)    # True
```


删除元素：del 字典\[键]

能删单一的元素也能清空字典，显式删除一个字典用del命令

```python title="示例"
mydic = {'Name': 'Runoob', 'Age': 7, 'Class': 'First'}
del mydic['Name']   # 删除键 'Name'
print (mydic)       # {'Age': 7, 'Class': 'First'}
mydic.clear()       # 清空字典
print (mydic)       # {}
del mydic           # 删除字典
```


**字典特性**

不允许同一个键出现两次，否则后一个覆盖前一个

```python title="示例"
mydic = {'Name': 'jack', 'Age': 27, 'Name': 'karen'}
print (mydic['Name'])     # karen
```


键必须不可变，可以用数字、字符串或元组，列表不行

```python title="示例"
mydic1 = {97:"a",98:"b"}
mydic2 = {"name":"karen","age":27}
mydic3 = { ['Name'] : 'karen', 'Age': 27}
print(mydic3[['Name']])  #报错unhashable type: 'list'
```


**常用API**

官方文档：[https://docs.python.org/zh-cn/3.13/library/stdtypes.html#mapping-types-dict](https://docs.python.org/zh-cn/3.13/library/stdtypes.html#mapping-types-dict "https://docs.python.org/zh-cn/3.13/library/stdtypes.html#mapping-types-dict")

操作字典的函数

![](image/image_fK4TIA4kr2.png)

```python title="str(dict) -- 将字典转换为字符串表示形式，通常用于打印或日志记录，使其人类可读"
data = {'a': 1, 'b': 2}
s = str(data)
print(s)   # 输出: "{'a': 1, 'b': 2}"
print(type(s))   # 输出: <class 'str'> (确认它变成了字符串)
```


字典的方法

![](image/image_NP6FNIvCwk.png)

```python title="dict.clear() -- 需要复用字典变量，但不想创建新对象时使用"
cart = {'apple': 3, 'banana': 5}
print(f"购买前: {cart}")
cart.clear()   # 结账后清空购物车
print(f"购买后: {cart}")   # 输出: 购买后: {}
```


```python title="dict.copy() -- 浅拷贝：创建一个新字典，新字典的键值对指向原字典的值"
original = {'name': 'Tom', 'scores': [90, 80]}
# 错误做法：直接赋值
 wrong_copy = original 
wrong_copy['name'] = 'Jerry' 
print(original['name'])   # 输出: Jerry (原字典被改了！)
# 正确做法：使用 copy()
original = {'name': 'Tom', 'scores': [90, 80]}   # 重置
 safe_copy = original.copy() 
safe_copy['name'] = 'Jerry'
print(original['name'])   # 输出: Tom (原字典没变)
print(safe_copy['name'])  # 输出: Jerry
```


```python title="dict.get(key, default=None) -- 安全地获取键对应的值"
info = {'age': 18}
# 方法A: 直接访问 (风险：如果键不存在会报 KeyError)
 print(info['height'])  # 报错！ 
# 方法B: 使用 get (安全)
height = info.get('height') 
print(height)   # 输出: None
# 方法C: 使用 get 并设置默认值
height = info.get('height', 175) 
print(height)   # 输出: 175 (因为没找到height，所以返回默认值175)
```


```python title="key in dict -- 判断某个键是否存在于字典中，返回 True 或 False"
# 字典的查找速度极快(O(1)复杂度)，非常适合用来做存在性检查
permissions = {'admin': True, 'user': False}
if 'admin' in permissions:
    print("管理员权限已定义")
if 'guest' not in permissions:
    print("访客权限未定义")
```


```python title="dict.items(), dict.keys(), dict.values()"
scores = {'Math': 90, 'English': 85}
# 遍历键
# dict.keys(): 获取所有键
for k in scores.keys():
    print(f"科目: {k}")
# 遍历值
# dict.values(): 获取所有值
for v in scores.values():
    print(f"分数: {v}")
# 同时遍历键和值 (最常用)
# dict.items(): 获取所有键值对（元组形式）
for k, v in scores.items():
    print(f"{k} 考了 {v} 分")
```


![](image/image_k8btlq8lWy.png)

```python title="dict.update(dict2) -- 将另一个字典 dict2 的内容更新到当前字典中"
config = {'theme': 'light', 'lang': 'en'}
updates = {'lang': 'zh', 'version': '2.0'}
config.update(updates)
print(config)   # 输出: {'theme': 'light', 'lang': 'zh', 'version': '2.0'}
# 解释: lang 被覆盖为 'zh', version 被新增
```


```python title="pop(key, default) -- 删除指定键的元素，并返回被删除的值"
stack = {'task1': 'done', 'task2': 'pending'}
# 取出并删除 task1
result = stack.pop('task1')
print(result)      # 输出: done
print(stack)       # 输出: {'task2': 'pending'} (task1 没了)
# 尝试删除不存在的键，提供默认值防止报错
val = stack.pop('task3', 'Not Found')
print(val)         # 输出: Not Found
```


综合实战案例

```python title="模拟一个简单的用户管理流程"
# 初始化 (len, type)
users = {}
print(f"初始类型: {type(users)}, 人数: {len(users)}")

# 添加/更新用户 (update)
new_user = {'id': 101, 'name': 'Alice', 'role': 'admin'}
users.update({101: new_user})

# 安全检查 (in, get)
user_id = 101
if user_id in users:
    # 安全获取名字，如果没有 name 键则返回 'Unknown'
    name = users[user_id].get('name', 'Unknown')
    print(f"欢迎, {name}!")
else:
    print("用户不存在")

# 遍历展示 (items, keys, values)
print("--- 用户列表 ---")
for uid, info in users.items():
    print(f"ID: {uid}, 角色: {info.get('role')}")

# 移除用户 (pop)
removed_user = users.pop(101)
print(f"已移除用户: {removed_user['name']}")
print(f"剩余人数: {len(users)}")

# 清空系统 (clear)
users.clear()
print(f"系统清空后: {users}") # 输出: {}
```


#### **💜 集合set/固定集合frozenset**

set的元素值必须是不可变的，set中可以存储int、str、tuple等不可变类型，但不能存储 list、dict 等可变类型

![](image/image_gAGxUegtbh.png)

**集合创建**

```python title="创建集合的方式"
# 必须使用 set() 函数，不能使用s={}，在Python中，{}默认创建的是空字典，而不是空集合
s = set()             # 用函数空集合
s = {1, 2, 3, 4}      # 创建非空集合的字面值
s = set(range(5))     # 调用set(可迭代对象) 来创建集合 s={0, 1, 2, 3, 4}
s = set("ABC")        # s = {'B', 'C', 'A'}，集合是无序的（输出顺序可能与输入不同）
# 自动去重(唯一性)：集合中的元素必须是唯一的
s = set("ABCCCCCCC")  # s = {'B', 'C', 'A'}
s = set(['ABC'])      # s = {'ABC'} 使用 set()函数从列表创建集合
s = set((4, 5, 6, 7)) # 使用 set()函数从元组创建集合
```


```python title="创建固定集合frozensets的方式"
fs = frozenset()              # 空固定集合 fs = frozenset()
fs = frozenset([1, 2, 3])     # fs = frozenset({1, 2, 3})
```


![](image/image_4_gcvMJjw-.png)

注意：创建一个空集合必须用 set() 而不是 { }，因为 { } 是用来创建一个空字典

**集合操作**

官方文档：[https://docs.python.org/zh-cn/3.13/library/stdtypes.html#set-types-set-frozenset](https://docs.python.org/zh-cn/3.13/library/stdtypes.html#set-types-set-frozenset "https://docs.python.org/zh-cn/3.13/library/stdtypes.html#set-types-set-frozenset")

添加元素：将元素 x 添加到集合 s 中，如果元素已存在，则不进行任何操作

s.add( x ) 添加元素到集合

s.update( x ) 添加元素到集合，参数可以是列表,元组,字典等，x可以有多个，用逗号分开

```python title="示例"
s1 = set((4, 5, 6, 7))    # s1:{4, 5, 6, 7}
s1.add(100)   # 集合保持无序性，因此输出顺序可能与添加顺序不同
print(s1)   # {100, 4, 5, 6, 7}
s1.add([200, 300])   # 错误：将整个列表作为单个元素添加 

s1.update([200,300])
print(s1)   # {100, 4, 5, 6, 7, 200, 300}
s1.update()  # 不报错，但无效果（空参数等价于无操作）
 s1.add()      # 报错：缺少必需参数
```


```python title="update() 支持多种可迭代对象："
s1.update([200, 300])     # 列表
s1.update((400, 500))     # 元组
s1.update("ABC")          # 字符串（拆分为字符：{'A', 'B', 'C'}）
s1.update({600, 700})     # 集合（去重后合并）  
```


删除元素：

s.remove( x )：将元素 x 从集合 s 中移除，不存在会发生错误

s.discard( x )：将元素 x 从集合 s 中移除，不存在也不会发生错误

s.pop()：对集合进行无序的排列，后将这个无序排列集合的左面第一个元素进行删除

```python title="remove"
s1 = {10, 20, 30}
s1.remove(20)
print(s1)   # s1 = {10,30}
s1.remove(40)   # 报错
```


```python title="discard"
s1 = {10, 20, 30}
s1.discard(20)
print(s1)   # s1 = {10,30}
s1.discard(40)
```


```python title="pop"
s1 = {9,233,3,12,123,33,123,10, 20, 30}
s1.pop()
print(s1)   # {3, 233, 10, 9, 12, 20, 123, 30}
del s1    # 也可以直接删除整个集合
```


访问与修改：

集合是无序的、不可重复的数据结构，不能通过索引访问其元素。所以没有对应的修改功能

TODO：需要通过便利或者迭代器去访问

in/not in：x in s 判断元素 x 是否在集合s中，存在返回 True，不存在返回 False

```python title="示例"
s1 = {10, 20, 30}
print(20 in s1)    # True
```


**常用API**

| 方法                               | 描述                                             |
| -------------------------------- | ---------------------------------------------- |
| add()                            | 为集合添加元素                                        |
| clear()                          | 移除集合中的所有元素                                     |
| copy()                           | 拷贝一个集合                                         |
| difference()                     | 返回多个集合的差集                                      |
| difference\\\_update()           | 移除集合中的元素，该元素在指定的集合也存在                          |
| discard()                        | 删除集合中指定的元素                                     |
| intersection()                   | 返回集合的交集                                        |
| intersection\\\_update()         | 返回集合的交集，并更新到集合。                                |
| isdisjoint()                     | 判断两个集合是否包含相同的元素，如果没有返回 True，否则返回 False         |
| issubset()                       | 判断指定集合是否为该方法参数集合的子集                            |
| issuperset()                     | 判断该方法的参数集合是否为指定集合的子集                           |
| pop()                            | 随机移除元素                                         |
| remove()                         | 移除指定元素                                         |
| symmetric\\\_difference()        | 返回两个集合中不重复的元素集合                                |
| symmetric\_difference\_ update() | 移除当前集合中在另外一个指定集合相同的元素，并将另外一个指定集合中不同的元素插入到当前集合中 |
| union()                          | 返回两个集合的并集                                      |
| update()                         | 给集合添加元素                                        |
| len()                            | 计算集合元素个数                                       |

```python title="示例"
# len()
s1 = {10, 20, 30}
print(len(s1))   # 3

# clear()
s1 = {10, 20, 30}
s1.clear()
print(s1)    # set()

# union():返回两个集合的并集
set1 = {1, 2, 3}
set2 = {3, 4, 5}
set3 = {5, 6, 7}
result = set1.union(set2, set3)
print(result)     # {1, 2, 3, 4, 5, 6, 7}
```


#### **🩶 字节串 bytes/字节数组 bytearray**

在 Python 中，处理文本使用 str，而处理二进制数据（如图片、音频、视频、网络协议包、加密数据）则必须使用 bytes 或 bytearray

关键区别：str 是给人看的(抽象层)，bytes/bytearray 是给机器/网络/磁盘看的(物理层)

![](image/image_82Ql2K9VED.png)

**核心定义与特性**

![](image/image_lagmPVgXMO.png)

**创建方式**

```python title="bytes 的创建"
# 字面量 (仅限ASCII和转义字符)
b1 = b'Hello'            
b2 = b'\x48\x65\x6c\x6c\x6f'  # 十六进制表示

# 字符串编码 (最常用)
text = "你好"
b3 = text.encode('utf-8')     # 转为 UTF-8 字节串
b4 = text.encode('gbk')       # 转为 GBK 字节串

# 整数列表 (0-255)
b5 = bytes([72, 101, 108, 108, 111])   # H e l l o

# 指定长度 (初始化为0)
b6 = bytes(10)  # b'\x00\x00...' (10个零字节)
```


```python title="bytearray 的创建"
# 从bytes复制
ba1 = bytearray(b'Hello')   # bytearray(b'Hello')

# 从字符串编码
ba2 = bytearray("你好", 'utf-8')   # bytearray(b'\xe4\xbd\xa0\xe5\xa5\xbd')

# 从整数列表
ba3 = bytearray([65, 66, 67])   # bytearray(b'ABC')

# 指定长度 (预分配缓冲区)
ba4 = bytearray(100)     # 创建 100 字节的空缓冲区，效率极高
```


**常用操作对比**

```python title="两者都支持索引、切片、遍历、拼接 (+)、重复 (*) 以及大部分查询方法"
data_b = b'Python'
data_ba = bytearray(b'Python')
print(type(data_b))   # <class 'bytes'>
print(type(data_ba))  # <class 'bytearray'>

# 索引 (返回整数)
print(data_b[0])      # 80 (ASCII 码)
print(data_ba[0])     # 80

# 切片 (返回同类型对象)
print(data_b[1:4])    # b'yth'
print(data_ba[1:4])   # bytearray(b'yth')

# 常用方法
print(data_b.find(b'tho'))         # 2
print(data_b.replace(b't', b'T'))  # b'PyThon' (返回新对象)
print(data_b.decode('utf-8'))      # 'Python' (转回字符串)
```


```python title="bytearray 独有的修改操作 (Mutable Only)"
ba = bytearray(b'ABC')

# 单个赋值 (必须是 0-255 的整数)
ba[0] = 90    # bytearray(b'ZBC')
ba[0] = 'Z'    # 报错，必须赋整数 

# 切片赋值 (可改变长度)
ba[1:3] = b'XY'      # bytearray(b'ZXY')
ba[1:2] = b'123'     # 扩容替换 (1个变3个)：bytearray(b'Z123Y')

# 列表风格的方法
ba.append(33)        # 追加'!'：bytearray(b'Z123Y!')
ba.extend(b' World') # 扩展：bytearray(b'Z123Y! World')
ba.insert(0, 72)     # 插入'H'：bytearray(b'HZ123Y! World')
ba.pop()             # 弹出末尾：bytearray(b'HZ123Y! Worl')
ba.remove(33)        # 移除第一个匹配的字节：bytearray(b'HZ123Y Worl')
ba.reverse()         # 原地反转：bytearray(b'lroW Y321ZH')
```


## ⭐**可变与不可变**

Python中，变量的值分为可变或不可变，该特征决定了变量在赋值、修改时的行为和性能

### **不可变类型**

对象一旦创建，其内部状态(值)永远无法被修改。任何看似"修改"的操作，实际上都是创建了一个新对象，并将变量名指向这个新对象

![](image/image_Q7LmitA7rk.png)

**数值类型：** int、float、complex

```python title="数字的值一旦赋值，不能被修改"
x = 10
 # id()：获取变量引用的内存地址
# hex()：转换为16进制 
print(id(x), hex(id(x)))   # 140717314108120 0x7ffb4d856ad8
x = x + 5  # 会创建一个新的整数对象，并将其赋值给 x
print(id(x), hex(id(x)))   # 140717314108280 0x7ffb4d856b78
```


![](image/image_m18aEkwYPI.png.mark.png)

Python 的变量是引用：变量名是对象的标签，而非对象本身

赋值 = 对于可变对象是引用传递：l2 = l1 让两个变量共享同一个对象

可变对象的原地修改：对可变对象(如列表)的修改会直接影响所有引用它的变量

![](image/image_052ssd0eC7.png)

修改对象：改"房间里的东西"，所有有钥匙的人都会看到变化
重新赋值：给一个人一把"新房子的钥匙"，其他人手里的旧钥匙不受影响

![](image/image_zw2PSORnEf.png.mark.png)

**字符串：** 字符串是不可变的，任何试图修改字符串内容的操作都会生成一个新的字符串

```python title="示例"
s = "hello"
print(id(s))   # 2516848500896
s = s + " world"  # 创建一个新的字符串对象并赋值给 s
print(id(s))   # 2514728691888
```


**元组：** 元组是不可变的容器类型，一旦创建，其内容不能更改

```python title="示例"
t = (1, 2, 3)
# t[0] = 10  # 会TypeError: 'tuple' object does not support item assignment
```


**冻结集合：** frozenset 是不可变版本的集合，一旦创建，无法修改其元素

```python title="示例"
fs = frozenset([1, 2, 3])
# fs.add(4)  # 会AttributeError: 'frozenset' object has no attribute 'add'
```


**布尔值：** 布尔值 True 和 False 也属于不可变类型

```python title="示例"
flag = True
flag = False  # 这不是修改，而是创建了一个新的布尔值并赋值给flag  
```


**字节串和None：** 字节串和None为不可变类型

### **可变类型**

可变类型的值在创建后可以被修改。常见的可变类型：

**列表：** 列表是可变的，可以在原地修改其元素、添加或删除元素

```python title="示例"
lst = [1, 2, 3]
lst[0] = 10  # 修改原列表的元素
lst.append(4)  # 添加新的元素
```


**字典：** 字典也是可变类型，可以修改其键值对

```python title="示例"
d = {'a': 1, 'b': 2}
d['a'] = 10  # 修改字典中键 'a' 对应的值
d['c'] = 3   # 添加新的键值对
```


**集合：** 集合是可变的，可以添加或删除元素

```python title="示例"
s = {1, 2, 3}
s.add(4)  # 添加元素
s.remove(2)  # 删除元素
```


**自定义对象：** 自定义类的实例如果没有在类中明确限制其属性，可以修改实例的属性值，因此对象实例也是可变的

```python title="示例"
class MyClass:
    def __init__(self):
        self.value = 0
obj = MyClass()
obj.value = 10  # 修改对象的属性
```


### **二者区别**

**内存管理**

对不可变类型改值时，Python会创建一个新的对象，并将该对象的引用赋给原来的变量

对可变类型修改内容时，不会创建新的对象，而是直接在原地进行修改

![](image/image_woKm91CPOq.png)

```python title="深拷贝vs浅拷贝"
import copy
original = [1, 2, [3, 4]]
shallow = original.copy()       # 浅拷贝：外层独立，内层共享
deep = copy.deepcopy(original)  # 深拷贝：完全独立

original[2].append(5)
print(shallow)    # [1, 2, [3, 4, 5]] -> 内层列表被影响了
print(deep)       # [1, 2, [3, 4]]   -> 完全不受影响
```


**行为差异**

不可变对象的引用在修改后会指向一个新对象，而可变对象的引用在修改时仍然指向原始对象

**作为字典键**

字典通过计算键的哈希值来快速定位数据，如果键是可变的(如列表)，其内容改变会导致哈希值改变，字典就无法找到原来的数据了

不可变类型具有固定的哈希值，可以作为字典的键

可变类型哈希值可能变化，不能作为字典的键

```python title="示例"
d = {}
d[(1, 2)] = "tuple key"    # 元组是不可变的，可以作为字典的键
d[[1, 2]] = "list key"     # 会抛出 TypeError: unhashable type: 'list'
```


注意：以上是基于修改而不是赋值，重新赋值操作都会指向新的对象引用

## ⭐类型判断与转换速查表

#### **类型判断**

使用 isinstance() 比 type() 更推荐，因为它支持继承关系的判断

```python title="使用isinstance判断类型变量"
a = 1
print(isinstance(a, int))   #判断是否属于指定类型 -> True
str1 = 'abc'
print(isinstance(str1, (int, str)))   #判断是否属于多个类型之一 -> True
```


#### **类型转换**

| **函数**​      | **说明**​                            | **示例**​                                   |
| ------------ | ---------------------------------- | ----------------------------------------- |
| int(x)       | 将x转换为整数类型                          | int("10") → 10                            |
| float(x)     | 将x转换为浮点数类型                         | float("3.14") → 3.14                      |
| str(x)       | 将x转换为字符串类型                         | str(123) → "123"                          |
| list(x)      | 将x转换为列表类型，x必须是可迭代对象                | list((1,2,2))→ \\\[1,2,3]                 |
| tuple(x)     | 将x转换为元组类型，x必须是可迭代对象                | tuple(\\\[1,2,3]) →(1,2,3)                |
| set(x)       | 将x转换为集合类型，x必须是可迭代对象                | set(\\\[1,2,3]) →{1,2,3}                  |
| dict(x)      | 将x转换为字典类型，x必须是可迭代的键值对序列（如列表、元组）    | dict(\\\[('a':1),('b':2)])→ {'a':1,'b':2} |
| bool(x)      | 将x转换为布尔类型，x的值可以是任何对象，返回True或 False | bool(0)→False；bool("abc")→True            |
| frozenset(x) | 将 x 转换为冻结集合，x 必须是可迭代对象             | frozenset(\\\[1,2,3])→frozenset({1,2,3})  |
| bytes(x)     | 将 x 转换为字节串类型，x 可以是字符串、字节数组等        | bytes("hello","utf-8")→ b'hello'          |
| complex(x)   | 将 x 转换为复数类型                        | complex(2)→(2+0j)                         |
| chr(x)       | 将整数 x 转换为对应的字符，x 是Unicode码点        | chr(97)→'a'                               |
| ord(x)       | 将字符 x 转换为对应的整数，x 是一个单一字符           | ord('a')→97                               |
| eval(x)      | 将字符串 x 作为 Python 表达式进行求值并返回结果      | eval('3+4')→7                             |
| set(x)       | 将可迭代对象 x 转换为集合                     | set(\\\[1,2,2,3])→ {1,2,3}                |

```python title="转换异常示例"
# 错误示范
int("hello")      # ValueError: 无法将非数字字符串转为整数
int("3.14")       # ValueError: int() 不能直接处理带小数点的字符串，需先 float("3.14")
# 类型转换可能会引发错误或丢失信息，比如浮点数转换为整数时，小数部分会丢失
list(123)         # TypeError: 整数不是可迭代对象
```


—— 心情好的小球藻著🍀 ——

![  ](image/xqz轮廓_y3IXHrAIG_.png "  ")
