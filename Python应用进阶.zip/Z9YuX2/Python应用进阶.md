# Python应用进阶

## 目录

- [函数式编程](#函数式编程)
  - [⭐ 闭包（Closure）](#-闭包Closure)
  - [⭐ 装饰器（Decorator）](#-装饰器Decorator)
    - [基础装饰器解析](#基础装饰器解析)
    - [装饰器分类](#装饰器分类)
      - [🟡 基础装饰器（无参数）](#-基础装饰器无参数)
      - [🟢 带参数装饰器（装饰器工厂）](#-带参数装饰器装饰器工厂)
      - [🔵 装饰器链（多个装饰器叠加）](#-装饰器链多个装饰器叠加)
      - [🟣 类装饰器](#-类装饰器)
- [面向对象编程](#面向对象编程)
  - [⭐ 类和对象](#-类和对象)
    - [类 (Class)](#类-Class)
    - [对象 (Object)](#对象-Object)
  - [⭐ 属性和方法](#-属性和方法)
    - [对象的创建与初始化](#对象的创建与初始化)
      - [🟡 构造方法：\_\_new\_\_(创建对象)](#-构造方法__new__创建对象)
      - [🟢 初始化方法：\_\_init\_\_(初始化对象)](#-初始化方法__init__初始化对象)
    - [属性(数据）](#属性数据)
      - [🟡 实例属性](#-实例属性)
      - [🟢 类属性](#-类属性)
    - [方法(函数）](#方法函数)
      - [🟡 实例方法](#-实例方法)
      - [🟢 类方法](#-类方法)
      - [🔵 静态方法](#-静态方法)
      - [🪻 魔术方法](#-魔术方法)
  - [⭐ 面向对象编程(OOP)四大特性](#-面向对象编程OOP四大特性)
    - [🌺 封装(Encapsulation)](#-封装Encapsulation)
    - [🌻 继承(Inheritance)](#-继承Inheritance)
    - [🌵 多态(Polymorphism)](#-多态Polymorphism)
    - [🧊 抽象(Abstraction)](#-抽象Abstraction)
  - [⭐ SUPER函数](#-SUPER函数)
    - [super() 的两种写法](#super-的两种写法)
    - [super ().\_\_init\_\_()](#super-__init__)
    - [MRO方法解析顺序](#MRO方法解析顺序)
- [迭代器和生成器](#迭代器和生成器)
  - [⭐ 迭代器Iterator](#-迭代器Iterator)
    - [迭代器协议(Iterator Protocol)](#迭代器协议Iterator-Protocol)
    - [迭代器的创建](#迭代器的创建)
    - [注意事项](#注意事项)
  - [⭐ 生成器Generator](#-生成器Generator)
    - [生成器原理](#生成器原理)
    - [生成器的创建](#生成器的创建)
      - [生成器函数](#生成器函数)
      - [生成器表达式](#生成器表达式)
    - [注意事项](#注意事项)
- [类型注解Type Hinting](#类型注解Type-Hinting)
  - [⭐ 标准用法](#-标准用法)
    - [变量注解 ❄️](#变量注解-️)
    - [函数注解 🧊](#函数注解-)
    - [容器类型注解 ❄️(list/dict/tuple/set）](#容器类型注解-️listdicttupleset)
    - [复杂类型注解 ❄️](#复杂类型注解-️)
    - [自定义类型](#自定义类型)
    - [Any与NoReturn](#Any与NoReturn)
  - [⭐ 静态类型检查（mypy）](#-静态类型检查mypy)

# 函数式编程

Python的函数式编程（Functional Programming, FP）是一种编程范式

函数式编程就是把"函数"当成"积木"来拼搭程序的编程思路

> 【举例】做一杯奶茶(完成一个程序功能)：
>
> 传统思路(命令式)：一步步说"先拿杯子→加珍珠→加奶茶底→加冰→摇匀"（关注步骤）
>
> 函数式思路：把"加珍珠""加奶茶底""加冰"都做成独立的"工具(函数)"，直接组合这些工具：做奶茶 = 加珍珠 + 加奶茶底 + 加冰（关注组合工具，而非步骤细节）

## ⭐ 闭包（Closure）

闭包是引用了此函数外部嵌套函数的变量的函数，并把该函数作为返回值

**原理：** 当外部函数执行完毕后，其作用域不会被销毁(因为内嵌函数仍在引用其中的变量)，变量会绑定到内嵌函数上，直到内嵌函数被销毁

**闭包必须满足以下三个条件：**

必须有一个内嵌函数

内嵌函数必须引用外部函数中变量

外部函数返回值必须是内嵌函数

```python title="闭包示例"
def give_yasuiqian(money):
    def child_buy(obj, m):
        # 内嵌函数默认只能读取外部函数的变量，无法直接修改（会被视为内嵌函数的局部变量）
        # nonlocal money 声明告诉解释器：
        # money不是当前内嵌函数的局部变量，而是来自外部嵌套函数的变量，允许修改
        nonlocal money
        if money > m:
            money -= m
            print('买', obj, '花了', m, '元, 剩余', money, '元')
        else:
            print("买", obj, '失败')
    return child_buy
cb = give_yasuiqian(1000)    
cb('变形金刚', 200)    # 买 变形金刚 花了 200 元, 剩余 800 元
cb('漫画三国', 100)    # 剩余700元（money变量仍保留上一次修改后的值）
cb('手机', 1300)      # 买 手机 失败
del cb  # 销毁闭包，money变量才会被回收
```


**优点**：

1. 逻辑连续，当闭包作为另一个函数调用参数时，避免脱离当前逻辑而单独编写额外逻辑
2. 方便调用上下文的局部变量
3. 加强封装性，是第2点的延伸，可以达到对变量的保护作用(外部无法直接修改money，只能通过child\_buy方法操作，保证数据安全)

**缺点**：引用在，空间不灭：闭包使得函数中的变量保存在内存中，内存消耗很大

## ⭐ 装饰器（Decorator）

本质：装饰器是闭包的语法糖，专门用于"增强函数功能"的闭包变种，其功能就是在不破坏目标函数原有的代码和功能的前提下，为目标函数增加新功能：

1. 日志记录：可以使用装饰器来记录函数的输入、输出或执行时间
2. 认证和授权：装饰器可以用于检查用户是否有权限执行特定操作
3. 缓存：装饰器可以缓存函数的结果，从而提高执行效率
4. 参数验证：可以使用装饰器来验证函数的输入参数是否符合预期
5. 代码注入：装饰器可以在函数的执行前后注入额外的代码

核心逻辑：

1. 接收一个函数作为参数(被装饰的函数)
2. 定义一个包装函数(内嵌函数)，在包装函数中：

   执行增强逻辑(如计时、日志)，调用原函数并保留其返回值
3. 返回包装函数，替换原函数

语法糖：`@装饰器名`是`原函数 = 装饰器(原函数)`的简写，让代码更简洁

### 基础装饰器解析

```python title="性能监控示例"
import time

# 装饰器函数：接收被装饰的函数作为参数
def performance_timer(func):
    # 包装函数：接收任意参数（*args 接收位置参数，**kwargs 接收关键字参数）
    def wrapper(*args, **kwargs):
        # 增强逻辑1：记录开始时间
        start = time.time()
        # 调用原函数，保留原函数的参数和返回值
        result = func(*args, **kwargs)
        # 增强逻辑2：计算并打印耗时
        print(f"{func.__name__}耗时: {time.time()-start}秒")
        # 返回原函数的结果，保证被装饰函数的返回值不变
        return result
    # 返回包装函数，替换原函数
    return wrapper

# 语法糖：等价于 time_consuming_func = performance_timer(time_consuming_func)
@performance_timer
def time_consuming_func():
    time.sleep(2)  # 模拟耗时操作

# 调用被装饰后的函数（实际调用的是 wrapper 函数）
time_consuming_func()
```


\*args, \*\*kwargs：保证装饰器能适配任意参数的函数，通用性强

result = func(\*args, \*\*kwargs)和return result，避免装饰器破坏原函数的返回逻辑

func.\_\_name\_\_：获取原函数的名称，让日志/输出更易读

### 装饰器分类

#### 🟡 **基础装饰器**（无参数）

适用场景：增强逻辑固定，无需外部配置（如单纯计时、日志）

```python title="基本装饰器"
def my_decorator(func):
    print("I am decorator")
    def wrapper():
        print("Something is happening before the function is called.")
        func()  # 调用传入的函数
        print("Something is happening after the function is called.")
    return wrapper

# 等价于：say_hello = my_decorator(say_hello)    
@my_decorator   # 应用装饰器：把下面函数作为实参传入装饰器函数
def say_hello():
    print("Hello!")
    
# say_hello是函数对象本身，代表对函数的引用而不执行任何代码
print("say_hello is:", say_hello)  # 装饰器装饰之后的函数，实际上指向的是wrapper函数
# say_hello()是调用操作符，它会立即执行该函数对象内部封装的逻辑并返回结果
say_hello()  # 调用经过装饰器之后的函数
```


![](image/image_IRXor_kmpv.png)

> **执行流程详解**
>
> ① 定义my\_decorator函数：此时只是定义，不执行任何打印或逻辑
>
> ② 遇到@my\_decorator：@my\_decorator等价于在定义完say\_hello后立即执行
>
> 也就是说，当Python解释器读到@my\_decorator这一行时，它会立即调用 my\_decorator函数，并把刚刚定义的say\_hello函数作为参数传进去
>
> 所以输出第一行：I am decorator
>
> 然后，my\_decorator内部定义了wrapper函数，并返回它
>
> 于是，原来的say\_hello函数被替换成了wrapper函数
>
> ③ 执行print("say\_hello is:", say\_hello)：这时say\_hello已经不是原来那个打印 "Hello!" 的函数了，而是my\_decorator返回的wrapper函数
>
> 所以输出：say\_hello is: \<function my\_decorator.\<locals>.wrapper at 0x...>
>
> 表明say\_hello现在是一个嵌套在my\_decorator内部的局部函数wrapper
>
> ④ 调用say\_hello()：由于say\_hello现在是wrapper，所以实际执行的是wrapper()
>
> 所以依次输出：
>
> Something is happening before the function is called. &#x20;
> Hello! &#x20;
> Something is happening after the function is called.

```python title="my_decorator函数为Qwen模型添加了执行时间记录和日志功能"
import time
# 定义装饰器函数，接收被装饰的函数作为参数
def my_decorator(fn):
    print("...装饰器函数被调用...")  # 装饰器应用时执行（仅一次）
    print('装饰的函数', fn)
    # 定义包装函数，用于增强原函数功能
    def wrapper():
        start_time = time.time()    # 时间戳：1970-01-01 00:00:00 到现在的毫秒数
        # 通用的功能增强（如日志记录、性能监控等）
        with open('log.txt', 'a') as f:
            f.write('...开始装饰...')            
            # 调用原函数并获取结果
             result = fn()   # 执行被装饰的函数（如Qwen()） 
            # 记录结束时间并计算耗时
            end_time = time.time()
            # 追加日志：记录函数执行耗时
            with open('log.txt', 'a') as f1:
                f1.write(f"Qwen模型执行完毕，耗时{end_time-start_time}秒...\n")
        return result  # 返回原函数的结果
    return wrapper  # 返回包装函数（替代原函数）

# 使用装饰器语法糖：等价于 Qwen = my_decorator(Qwen)
@my_decorator     
def Qwen():
    time.sleep(2)  # 模拟耗时操作（休眠2秒）
    print("Qwen模型进行内容生成！")
    return "生成的内容"  # 返回生成的内容
    
# 调用被装饰后的函数（实际调用的是wrapper()）
generator = Qwen()
print('...Qwen大模型生成内容...', generator)
```


![](image/image_Z7jLrAGNhf.png)

![](image/image_sdberYgNuA.png)

进阶优化：使用functools.wraps 保留原函数的元信息（如函数名、文档字符串）

```python title="使用functools.wraps 保留原函数的元信息"
import time
from functools import wraps

def performance_timer(func):
    @wraps(func)  # 保留原函数的元信息
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        print(f"{func.__name__}耗时: {time.time()-start}秒")
        return result
    return wrapper

@performance_timer
def time_consuming_func():
    """模拟耗时函数"""
    time.sleep(2)

print(time_consuming_func.__name__)  
# 输出：time_consuming_func（未用wraps则输出wrapper）
print(time_consuming_func.__doc__)   
# 输出：模拟耗时函数（未用wraps则为None，因为wrapper没写文档）
time_consuming_func()

```


![](image/image_6zQb62PNjz.png)

问题背景：在普通的装饰器中，wrapper函数会完全覆盖原函数。如果打印func.\_\_name\_\_或 func.\_\_doc\_\_，得到的将是"wrapper"和None(或者wrapper的文档)，而不是原函数的信息。这会导致调试困难，且某些依赖元数据的库(如Flask路由、文档生成工具)会失效

解决方案：@wraps(func)是functools模块提供的一个装饰器。它把原函数func的元数据(包括 \_\_name\_\_, \_\_doc\_\_, \_\_module\_\_, \_\_qualname\_\_, \_\_annotations\_\_, \_\_dict\_\_等)复制给内部的 wrapper函数，经过@wraps处理后，wrapper在Python看来"就是"原函数 time\_consuming\_func，只是行为被增强了

#### 🟢 **带参数装饰器**（装饰器工厂）

适用场景：增强逻辑需要外部配置（如重复执行n次、指定日志级别）

核心逻辑：外层函数接收装饰器参数 → 返回基础装饰器 → 基础装饰器返回包装函数

![](image/image_pf5sMK8UsN.png)

```python title="带参装饰器"
def repeat(num):
    print('...函数名...()...函数执行...')
    def decorator(func):
        print('...装饰器...()...装饰器执行...')
        def wrapper(*args, **kwargs):
            for _ in range(num):
                func(*args, **kwargs)
        return wrapper
    return decorator
    
# 应用装饰器，重复执行下面的函数3次，等价于 greet = repeat(3)(greet)
@repeat(3)  
def greet(name):
    print(f"Hello, {name}!")
# 调用被装饰的函数
greet("Alice")  # 输出三次 "Hello, Alice!"
```


![](image/image_zFy61_cxAU.png)

> **执行流程详解**
>
> ① 解析@repeat(3)：先执行repeat(3)，返回decorator函数，装饰器工厂执行，接收参数 num=3，打印...函数名...()...函数执行...
>
> ② 绑定greet函数：执行decorator(greet)，返回wrapper，基础装饰器执行，绑定函数 greet，输出...装饰器...()...装饰器执行...
>
> ③ 调用greet("Alice")：执行wrapper("Alice")，开始重复执行3次输出Hello, Alice!

```python title="权限校验装饰器"
from functools import wraps

def check_permission(required_role):
    """带参数的装饰器：校验用户角色"""
    def decorator(func):
        @wraps(func)
        def wrapper(user_role, *args, **kwargs):
            if user_role == required_role:
                print(f"权限校验通过：{user_role} 可执行 {func.__name__}")
                return func(user_role, *args, **kwargs)
            else:
                raise PermissionError(f"权限不足")
        return wrapper
    return decorator

# 应用装饰器：要求admin角色
@check_permission(required_role="admin")
def delete_file(user_role, filename):
    print(f"成功删除文件：{filename}")

# 调用测试
delete_file("admin", "test.txt")  # 正常执行
delete_file("user", "test.txt")   # 抛出PermissionError
```


![](image/image_shpf0VCh6A.png)

#### 🔵 **装饰器链**（多个装饰器叠加）

适用场景：需要为函数叠加多个增强功能(如先转大写、再加感叹号，先校验权限、再计时)

装饰器链的执行顺序：自下而上绑定，自上而下执行（即离函数最近的装饰器先绑定、先执行）

```python title="装饰器链"
# 定义第一个装饰器：将结果转为大写
def uppercase(func):
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)  # 调用原函数
        return result.upper()          # 将结果转为大写
    return wrapper
# 定义第二个装饰器：在结果末尾添加感叹号
def exclamation(func):
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)  # 调用原函数
        return result + "!"            # 在结果后添加感叹号
    return wrapper
    
# 装饰器链：先应用 @uppercase，再应用 @exclamation
# 等价于 say_hello = exclamation(uppercase(say_hello))
@exclamation
@uppercase
def say_hello(name):
    return f"Hello, {name}" 
    
# 调用被装饰后的函数
greeting = say_hello("Bob")
print(greeting)  # 输出 "HELLO, BOB!"
```


> **执行流程详解**
>
> ① 装饰阶段(定义时)：
>
> 先执行uppercase(say\_hello) → 生成函数 A
>
> 再执行exclamation(函数 A) → 生成函数 B
>
> 最终say\_hello指向函数B，数学表达：say\_hello = exclamation(uppercase(say\_hello))
>
> ② 调用阶段(运行时)：
>
> 调用say\_hello("Bob")即调用函数B
>
> 函数B (exclamation 的wrapper) 先运行 → 调用函数A
>
> 函数A (uppercase的wrapper) 运行 → 调用原函数
>
> 原函数返回"Hello, Bob" → A转为"HELLO, BOB" → B 加上"!" → 最终返回"HELLO, BOB!"

#### 🟣 类装饰器

适用场景：需要封装更复杂的增强逻辑，或需要维护状态(如计数、缓存)时

核心原理：类装饰器需实现\_\_init\_\_(接收被装饰函数)和\_\_call\_\_(执行增强逻辑，替代包装函数)方法

```python title="类装饰器"
class MyDecorator:
    def __init__(self, func):
        self.func = func
    def __call__(self, *args, **kwargs):
        print("Something is happening before the function is called.")
        result = self.func(*args, **kwargs)
        print("Something is happening after the function is called.")
        return result
        
@MyDecorator  # 应用类装饰器
def say_hello(name):
    print(f"Hello, {name}!")
    
say_hello("Charlie")  # 调用被装饰的函数
```


![](image/image_oFE6eDYTvh.png)

MyDecorator是一个类装饰器，它接受一个函数func 数并在 \_*call*\_ 方法中执行额外操作

```python title="举例"
class CountCalls:
    def __init__(self, func):
        self.func = func
        self.count = 0
    def __call__(self, *args, **kwargs):
        self.count += 1
        print(f"调用次数: {self.count}")
        return self.func(*args, **kwargs)

@CountCalls
def say_hi():
    print("Hi!")

say_hi()    # 调用次数: 1/n   Hi
say_hi()    # 调用次数: 2/n   Hi

```


# 面向对象编程

面向对象编程(OOP)是一种以"对象"为核心的编程思想，把程序看作是一个个独立对象的集合，每个对象都有自己的"特征"(属性)和"行为"(方法)，Python是面向对象的模块化编程，一切皆对象(数字、字符串、列表等本质都是对象)

类比：把"人"看作一个类，那么"张三"、"李四"就是这个类的具体对象，"姓名、年龄" 是属性，"吃饭、走路" 是方法

![](image/image_fHB2l2c6kP.png)

## ⭐ 类和对象

### 类 (Class)

类是对一类事物的抽象定义，是对象的模板或蓝图。它规定了这类事物有哪些共同特征(属性)和行为(方法)，但不包含具体数据

类是容器：类将数据和操作数据的代码捆绑在一起

*没有类之前*：变量(数据)和函数(行为)是分离的，容易乱套(比如用处理狗的函数去处理猫的数据)

*有了类之后*：数据和方法被"锁"在同一个盒子里。方法只能操作自己盒子里的数据(通过self)

数据成员是类的静态部分，负责存储状态(名词)，决定了对象"是什么样子的"(状态）

方法成员是类的动态部分，负责处理逻辑(动词)，并且通常是唯一被允许安全地修改数据成员的途径，决定了对象"能做什么"(行为)

**通过class关键字定义类**

![](image/image_H9GfP27Yzc.png)

```python title="类的定义规则"
class 类名(继承列表):  # 类名建议首字母大写(大驼峰命名法)，继承列表可选
    # 类变量（所有对象共享的属性）
    类变量名 = 初始值
    
    # 初始化方法(构造方法)：创建对象时自动执行，用于初始化对象属性
    def __init__(self, 参数1, 参数2...):
        # 实例属性：每个对象独有的属性，通过self.属性名定义
        self.属性名1 = 参数1
        self.属性名2 = 参数2
    
    # 实例方法：对象的行为，第一个参数必须是self
    def 方法名(self, 其他参数...):
        方法体
        
    # 类方法(可选)：操作类变量，用@classmethod装饰，第一个参数是cls(代表类本身)
    @classmethod
    def 类方法名(cls, 参数...):
        方法体
        
    # 静态方法(可选)：与类/对象无关的工具方法，用@staticmethod装饰，无默认参数
    @staticmethod
    def 静态方法名(参数...):
        方法体
```


class：定义类的关键字

类名：标识符(首字母大写)，本质是绑定"类对象"的变量

self：代表实例化后的对象本身，谁调用方法，self就指向谁(无需手动传参)

\_\_init\_\_：魔术方法(初始化方法)，创建对象时自动执行，用于给对象绑定属性

实例属性：每个对象独有的属性(如人的姓名、生日)，通过self.属性名定义

实例方法：对象的行为，第一个参数必须是 self

```python title="定义一个 BankAccount (银行账户) 类"
class BankAccount:
    # 类变量：所有账户共有的特征
    bank_name = "未来银行"
    interest_rate = 0.03  # 年利率 3%

    def __init__(self, owner, balance):
        # 实例属性：每个账户独有的数据
        self.owner = owner      # 户主姓名
        self.balance = balance  # 余额
        # 注意：这里没有定义 account_id，假设它是自动生成的或外部传入
    
    # 实例方法：操作具体对象的数据
    def deposit(self, amount):
        """存款"""
        if amount > 0:
            self.balance += amount
            print(f"{self.owner} 存入 {amount}，当前余额：{self.balance}")
        else:
            print("存款金额必须大于0")

    def withdraw(self, amount):
        """取款"""
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"{self.owner} 取出 {amount}，当前余额：{self.balance}")
        else:
            print("余额不足或金额非法")

    # 类方法：修改类变量，或使用替代构造器
    @classmethod
    def change_interest_rate(cls, new_rate):
        """调整所有账户的利率"""
        cls.interest_rate = new_rate
        print(f"银行利率已调整为 {new_rate}")

    @classmethod
    def from_string(cls, account_str):
        """备用构造器：从 '姓名,余额' 字符串创建对象"""
        owner, balance_str = account_str.split(',')
        return cls(owner, float(balance_str))

    # 静态方法：与具体对象无关的工具
    @staticmethod
    def is_valid_amount(amount):
        """验证金额是否合法"""
        return isinstance(amount, (int, float)) and amount >= 0

# --- 使用演示 ---
# 创建两个对象 (实例化)
acc1 = BankAccount("张三", 1000)
acc2 = BankAccount("李四", 5000)

# 测试实例方法和实例属性
acc1.deposit(500)       # 张三存入，只影响 acc1
acc2.withdraw(1000)     # 李四取出，只影响 acc2
print(f"张三余额: {acc1.balance}, 李四余额: {acc2.balance}")
# 输出：张三余额: 1500, 李四余额: 4000 (互不影响)

# 测试类变量 (共享)
print(f"初始银行名: {acc1.bank_name}, {acc2.bank_name}") 
# 输出：未来银行, 未来银行

# 测试类方法 (修改共享数据)
BankAccount.change_interest_rate(0.05) 
# 输出：银行利率已调整为 0.05
print(f"新利率: {acc1.interest_rate}, {acc2.interest_rate}") 
# 输出：新利率: 0.05, 0.05

# 测试备用构造器
acc3 = BankAccount.from_string("王五,2000")
print(f"新对象: {acc3.owner}, 余额: {acc3.balance}")
# 输出：新对象: 王五, 余额: 2000.0

# 测试静态方法
print(f"100 是合法金额吗？{BankAccount.is_valid_amount(100)}") # True
print(f"-50 是合法金额吗？{BankAccount.is_valid_amount(-50)}") # False
```


### 对象 (Object)

对象是类的实例化结果，是类模板的"具体产品"，包含类定义的所有属性和方法，且有具体的数值

类参数按照初始化方法的形参传递

- 对象是类的实例，具有类定义的属性和方法
- 通过调用类的构造函数来创建对象
- 每个对象有自己的状态，但共享方法

```python title="创建对象的语法"
变量 = 类名([参数])
```


变量存储的是实例化后的对象地址

**创建对象的两种常见方式**

```python title="方式1：直接传参（最常用）"
# 创建第一个Human对象（具体的人：邓鸿）
p1 = Human("邓鸿","2004-07-01")
# 访问对象的属性：对象名.属性名
print(p1.username)  # 输出：邓鸿
# 调用对象的方法：对象名.方法名()
print(p1.showme())  # 输出：我的名字是：邓鸿，生日是：2004-07-01
```


```python title="方式 2：字典解包传参（适合参数多的场景）"
# 定义一个包含属性的字典
stu = {"username": "zzl", "birthday": "2004-10-06"}
# **stu ：将字典键值对解包为关键字参数（username="zzl", ...）
p2 = Human(**stu)
print(p2.birthday)  # 输出：2004-10-06
print(p2.showme())  # 输出：我的名字是：zzl，生日是：2004-10-06
```


**对象的核心特性**

每个对象独立：不同对象的内存地址不同(可通过id()查看)，属性值相互独立

```python title="代码示例"
print(id(p1))  # 输出p1的内存地址（2302597614288）
print(id(p2))  # 输出p2的内存地址（2302597597456）→ 与p1不同
```


共享类的方法：所有对象共用类中定义的方法，但方法内部通过 self 访问的是当前对象的属性

动态修改属性：对象创建后可随时修改属性值(灵活但需谨慎)

```python title="代码示例"
p1.age = 20            # 给p1新增age属性
p1.username = "邓小红"  # 修改p1的姓名属性
print(p1.showme())     # 输出：我的名字是：邓小红，生日是：2004-07-01
```


**完整示例代码**

```python title="自我介绍的类"
# 定义类
class Human:
    # 初始化方法（魔术方法）：创建对象时自动执行
    def __init__(self, username, birthday):
        # 绑定实例属性（每个对象独有的特征）
        self.username = username  # 姓名
        self.birthday = birthday  # 生日
    # 自定义实例方法（对象的行为）
    def showme(self):
        # self代表调用该方法的对象，此处可访问当前对象的所有属性
        return f'我的名字是：{self.username}，生日是：{self.birthday}'

# 实例化对象（创建具体的"人"）
# 方式1：直接传参
p1 = Human("邓鸿", "2004-07-01")
# 访问属性
print("p1的姓名：", p1.username)  # 输出：邓鸿

# 方式2：字典解包传参
stu = {"username": "zzl", "birthday": "2004-10-06"}
p2 = Human(**stu)
print("p2的生日：", p2.birthday)  # 输出：2004-10-06

# 调用方法
print(id(p1))       # 输出p1的内存地址（2302597614288）
print(id(p2))       # 输出p2的内存地址（2302597597456）
print(p1.showme())  # 输出：我的名字是：邓鸿，生日是：2004-07-01
print(p2.showme())  # 输出：我的名字是：zzl，生日是：2004-10-06
```


## ⭐ 属性和方法

类的属性和方法是类的核心组成部分，它们用于定义类的状态和行为

### 对象的创建与初始化

在Python 中，创建一个实例对象的过程分为两步：创建对象(分配内存)和初始化对象(设置属性)，对应两个特殊的方法：构造方法\_\_new\_\_和初始化方法\_\_init\_\_，二者分工明确，不可混淆

#### 🟡 构造方法：\_\_**new**\_\_(创建对象)

【**作用**】负责创建实例对象，分配内存空间，返回一个新的实例对象(这是对象存在的基础)

第一个参数是cls(指向类本身)，与类方法的cls 含义一致

必须返回一个实例对象(通常是调用父类的\_\_new\_\_方法创建，即super().\_\_new\_\_(cls))

无需手动调用，Python 在实例化时(类名(参数))会自动先调用\_\_new\_\_ 创建对象

```python title="构造方法__new__()"
class MyClass:
    # 定义 __new__ 方法：这是创建对象时最先调用的方法
    def  __new__ (cls, *args, **kwargs):
        print("调用 __new__ 方法，创建对象")
        # 使用 super() 调用父类（object）的 __new__ 方法来真正创建一个对象
        return super().__new__(cls)
        
    # 定义 __init__ 方法：用于初始化新创建的对象
    def __init__(self, value):
        print("调用 __init__ 方法，初始化对象")
        # 将传入的 value 参数赋值给实例属性 self.value
        self.value = value
        
# 创建 MyClass 的一个实例 obj，并传入参数 10
obj = MyClass(10)
```


![](image/image_A57CDsOGYT.png)

**注意事项**： &#x20;

通常无需自定义\_\_new\_\_方法，Python 会自动调用基类(object)的\_\_new\_\_方法，完成对象的创建和内存分配

```python title="不需要显式地定义 __new__() 方法"
class MyClass:
    def __init__(self, value):
        print("调用 __init__ 方法，初始化对象")
        self.value = value
# 创建对象
obj = MyClass(10)
```


![](image/image_Icku3ChiJc.png)

自定义\_\_new\_\_时，必须返回一个实例对象，否则\_\_init\_\_方法不会被调用(因为\_\_init\_\_需要接收\_\_new\_\_ 返回的实例)

```python title="定义__new__时，必须返回一个实例对象"
class MyClass:
    # 构造方法：创建对象，分配内存
    def __new__(cls, *args, **kwargs):
        print("调用__new__方法：创建对象，分配内存")
        # 调用父类（object）的__new__方法，真正创建实例对象
        instance = super().__new__(cls)
        return instance  # 必须返回实例对象，否则__init__不会执行
    # 初始化方法：初始化对象属性
    def __init__(self, value):
        print("调用__init__方法：初始化对象属性")
        self.value = value  # 给__new__创建的实例设置属性
# 实例化：自动先调用__new__，再调用__init__
obj = MyClass(10)
# 输出顺序：
# 调用__new__方法：创建对象，分配内存
# 调用__init__方法：初始化对象属性

# 错误示例：__new__不返回实例对象
class BadClass:
    def __new__(cls):
        print("创建对象，但不返回")
        # 无return语句，默认返回None
    def __init__(self):
        print("初始化对象")
# 实例化时，__init__不会被调用（因为__new__没有返回实例）
bad_obj = BadClass()  # 仅输出：创建对象，但不返回
```


![](image/image_MuZByPYv0C.png)

#### 🟢 初始化方法：\_\_**init**\_\_(初始化对象)

对象被\_\_new\_\_创建后，初始化实例属性，给实例设置初始值，不负责创建对象，仅"初始化"

第一个参数是self(指向\_\_new\_\_ 创建的实例对象)，无需手动传参，Python 自动传递

无返回值(若返回非None的值，会报错)

无需手动调用，Python 在\_\_new\_\_执行完毕并返回实例后，自动调用\_\_init\_\_

```python title="语法格式 -- 接收实参到 __init__方法中"
class 类名(继承列表):
    def __init__(self[, 形参列表]):     # [] 代表其中的内容可省略
        语句块

```


**注意事项**： &#x20;

\_\_init\_\_的参数的数量，必须与实例化时传入的参数数量一致(除了self)

实例属性必须在\_\_init\_\_中通过self.属性名 定义，否则在其他实例方法中无法直接访问(报错)

```python title="示例代码"
class Student:
    # 自定义初始化方法，接收3个参数（name, age, grade）
    def __init__(self, name, age, grade):
        # 初始化实例属性，每个实例的属性值可不同
        self.name = name    # 姓名
        self.age = age      # 年龄
        self.grade = grade  # 年级
        # 可在__init__中调用实例方法，初始化相关逻辑
        self.show_info()
    
    # 实例方法：展示学生信息
    def show_info(self):
        print(f"姓名：{self.name}，年龄：{self.age}，年级：{self.grade}")

# 实例化：传入3个参数，匹配__init__的参数（除self外）
stu1 = Student("张三", 15, "高一")  # 输出：姓名：张三，年龄：15，年级：高一
stu2 = Student("李四", 14, "初二")  # 输出：姓名：李四，年龄：14，年级：初二

# 错误示例1：实例化时参数数量不匹配
 stu3 = Student("王五", 16)  
# 报错：missing 1 required positional argument: 'grade'

# 错误示例2：未在__init__中定义实例属性，试图访问
class BadStudent:
    def __init__(self, name):
        self.name = name  # 只定义了name属性，没有定义age属性
    def show_age(self):
        print(self.age)  # age未在__init__中定义，报错

bad_stu = BadStudent("赵六")
 bad_stu.show_age()   
# 报错：'BadStudent' object has no attribute 'age'
```


### 属性(数据）

属性是类/对象的"状态/特征"，分为实例属性和类属性，核心区别是"归属不同、作用域不同"

#### 🟡 **实例属性**

实例属性属于单个对象，每个对象的实例属性相互独立(你改你的，我改我的，互不影响)

**定义方法**

```python title="方式 1：初始化时通过__init__绑定（推荐，规范）"
class Dog:
    def __init__(self, kinds, color):
        # 实例属性：每个Dog对象独有
        self.kinds = kinds  # 品种
        self.color = color  # 颜色
```


```python title="方式 2：对象创建后动态添加（灵活但不推荐，易出错）"
dog1 = Dog()  # 先创建空对象
dog1.kinds = "京巴"  # 动态添加属性
dog1.color = "白色"  # 动态添加属性
```


**访问/修改方式**

```python title="示例代码"
# 访问：对象名.属性名
print(dog1.color)     # 输出：白色
# 修改：对象名.属性名 = 新值
dog1.color = "黄色"   # 仅修改dog1的color，不影响其他对象
```


**核心特点**

独占性：每个对象的实例属性是独立的，修改A对象的属性不会影响B对象

关联性：实例方法中通过self.属性名访问当前对象的实例属性

```python title="示例代码，采用方式二添加实例属性"
class Dog:
    def eat(self, food):
        # self指向调用该方法的对象（如dog1调用则self=dog1）
        print(self.color, '的', self.kinds, '正在吃', food)

dog1 = Dog()
dog1.kinds = "京巴"
dog1.color = "白色"
dog1.eat("骨头")  # 输出：白色 的 京巴 正在吃 骨头
```


#### 🟢 类属性

类属性属于类本身，被该类的所有对象共享(相当于"全局变量")，常用于存储所有对象的公共数据

**定义方式**

```python title="直接在类内部、方法外部定义"
class Human:
    # 类属性：所有Human对象共享
    total_count = 0  # 记录人类总数
    species = "智人"  # 所有人类的物种属性
```


**访问/修改方式**

![](image/image_ZSmqX7D8FC.png.mark.png)

**核心特点**

共享性：修改类属性会影响所有对象的访问结果

```python title="代码示例"
Human.total_count = 10  # 修改类属性
h1 = Human()
h2 = Human()
print(h1.total_count)  # 输出：10（共享修改后的值）
print(h2.total_count)  # 输出：10
```


优先级：如果对象有和类属性同名的实例属性，会优先访问实例属性("就近原则")

```python title="代码示例"
h1.total_count = 5        # 给h1添加同名实例属性
print(h1.total_count)     # 输出：5（实例属性）
print(Human.total_count)  # 输出：10（类属性）
```


**实例属性 vs 类属性**

| 维度   | 实例属性                      | 类属性                                |
| ---- | ------------------------- | ---------------------------------- |
| 归属   | 单个对象                      | 类本身                                |
| 作用域  | 仅当前对象                     | 所有对象共享                             |
| 定义位置 | \ \_\_ init\ \_\_ 内/对象创建后 | 类内部、方法外部                           |
| 访问方式 | 对象名\*\* . \*\*属性名         | 类名 \*\*. \*\*属性名/对象名\*\* .\*\* 属性名 |
| 典型用途 | 存储对象个性化数据                 | 存储所有对象的公共数据                        |

### 方法(函数）

方法是类/对象的"行为/功能"，分为实例方法、类方法、静态方法，核心区别是"参数、归属、能访问的属性不同"

#### 🟡 实例方法

实例方法是最常用的方法，用于操作实例属性，必须有第一个参数self(指向调用该方法的对象)

```python title="定义/调用语法"
class 类名:
    # 实例方法：第一个参数必须是self
    def 方法名(self, 参数1, 参数2...):
        方法体（可访问self.实例属性）

# 调用：对象名.方法名(参数)（self无需手动传参）
对象名.方法名(参数1, 参数2...)
```


【**作用**】操作实例属性(赋值、修改、查询)，实现实例的具体行为(如对象的动作、功能)，无法直接操作类属性(需通过 类名.类属性 手动访问)

```python title="带有实例方法的简单的Dog类"
class Dog:
    def eat( self , food):  # 实例方法
        print("小狗正在吃", food)
    def sleep( self , hour):
        print("小狗睡了", hour, "小时!")

dog1 = Dog()
# 调用实例方法，self自动指向dog1
dog1.eat("骨头")    # 输出：小狗正在吃 骨头
dog1.sleep(1)      # 输出：小狗睡了 1 小时!
 help(Dog)  # 可以看到Dog类的文档信息
```


![](image/QQ_1773409202713_ncrNhXomkw.png.mark.png)

```python title="练习1"
class str:
    def __init__(self, value):  # 新增初始化方法，存储字符串值
        self.value = value  # 将传入的字符串保存到实例变量value中
        
    def center(self, width, fillchar=' '):
        newstr = ''
        if width <= len(self.value):  # 如果指定宽度小于等于原字符串长度，直接返回原字符串
            newstr = self.value
            return newstr
        # 计算两侧填充的长度（总宽度减去原字符串长度后平分）
        spacelen = (width - len(self.value)) // 2
        # 拼接填充字符+原字符串+填充字符，形成居中字符串
        newstr = fillchar * spacelen + self.value + fillchar * spacelen
        return newstr
        
    def count(self, sub):
        count = 0
        tmp = self.value  # 临时字符串，用于截取剩余部分
        sub_len = len(sub)  # 子串长度，避免重复计算
        # 若子串为空或长度为0，直接返回0（避免无效计算）
        if sub_len == 0:
            return 0
        # 遍历临时字符串，每次从当前位置开始查找子串
        while len(tmp) >= sub_len:
            # 检查当前位置是否匹配子串
            if tmp[:sub_len] == sub:
                count += 1
                # 匹配成功后，截取剩余部分（跳过已匹配的子串）
                tmp = tmp[sub_len:]
            else:
                # 匹配失败，向前移动1位继续查找
                tmp = tmp[1:]
        return count
str1 = str('hello')  # 创建str类实例，传入字符串'hello'
print('-', str1.center(12, '='), '-', sep='')
str2 = str('aaaaesjhuqhwaasjqiwjswiqoidjo')
print(str2.count('aa'))  
```


![](image/image_8fS2_dfKBv.png)

#### 🟢 类方法

类方法用于操作类属性，用@classmethod装饰，第一个参数固定为cls(指向类本身)

类方法只能通过cls操作类属性，无法直接访问此类创建的对象的实例属性(如self.xxx)

- 第一个参数固定为cls(参数名可自定义，但行业规范统一用cls)，cls 本质是"类本身"，无需手动传参，Python 会自动将调用方法的类赋值给cls
- 方法体中，通过cls.类属性名访问和修改类属性，无法直接访问实例属性(因为cls 指向类，而非实例，没有 self 对应的实例属性)

可通过类名(如A.get\_v())或实例(如a.get\_v())调用，类和该类的实例都可以调用类方法

【**作用**】操作类属性(赋值、修改、查询)，实现类的整体行为(如修改所有实例共享的类属性、创建类的实例等)，与单个实例的具体状态无关

```python title="类方法只认类，不认对象"
class A:
    v = 0  # 类属性
    @classmethod
    def set_v(cls, value):
        cls.v = value  # 修改类属性
    @classmethod
    def get_v(cls):
        return cls.v  # 获取类属性

print(A.get_v())  # 0
A.set_v(100)
print(A.get_v())  # 100
```


**易错点：**

忘记添加@classmethod 装饰器，此时方法会被当作实例方法，调用时报错(缺少self 参数)

试图通过cls 访问实例属性(如 cls.实例属性名)，会报错(类没有该实例属性)

混淆cls和self：cls 指向类，操作类属性；self 指向实例，操作实例属性，二者不可混用

```python title="完整示例代码"
class MyClass:
    # 类属性：所有实例共享，初始值为0
    cls_attr = 0
    def __init__(self, ins_attr):
        # 实例属性：每个实例独有
        self.ins_attr = ins_attr
    # 类方法1：修改类属性（通过cls）
    @classmethod
    def set_cls_attr(cls, new_val):
        cls.cls_attr = new_val  # 修改类属性，所有实例都会受影响
        print(f"类属性cls_attr已修改为：{cls.cls_attr}")
    # 类方法2：获取类属性，并创建类的实例
    @classmethod
    def get_attr_and_create(cls, ins_attr):
        print(f"当前类属性cls_attr：{cls.cls_attr}")
        return cls(ins_attr)  # 通过cls创建实例（等价于MyClass(ins_attr)）
    # 错误示例：类方法试图访问实例属性
    @classmethod
    def try_get_ins_attr(cls):
        try:
            print(cls.ins_attr)  # 试图通过cls访问实例属性，报错
        except AttributeError as e:
            # 错误：type object 'MyClass' has no attribute 'ins_attr'
            print(f"错误：{e}")  

# 类名调用类方法，修改类属性
MyClass.set_cls_attr(100)  # 输出：类属性cls_attr已修改为：100

# 类名调用类方法，获取类属性并创建实例
obj1 = MyClass.get_attr_and_create("实例1")  # 输出：当前类属性cls_attr：100

# 实例对象调用类方法（可行，但不推荐）
obj2 = MyClass("实例2")
obj2.set_cls_attr(200)  # 输出：类属性cls_attr已修改为：200

# 验证类属性的共享性：所有实例访问的类属性都是修改后的值
print(obj1.cls_attr)  # 200
print(obj2.cls_attr)  # 200
print(MyClass.cls_attr)  # 200
# 测试错误示例
MyClass.try_get_ins_attr()
```


![](image/image_1oebgwXtsD.png)

#### 🔵 静态方法

静态方法是定义在类内部的"工具方法"，既不属于类，也不属于实例，不依赖于类属性和实例属性，仅用于处理独立的逻辑(与类和实例无关)

必须用@staticmethod 装饰器(不可省略)，用于标识该方法是静态方法

无隐式参数(无需self或cls)，参数完全由开发者根据需求定义，与类和实例无关

方法体中，无法直接访问类属性和实例属性(若需访问，需手动传递类名或实例对象作为参数)

【作用】实现与类、实例无关的独立逻辑(如数据验证、工具计算等)，将相关的工具方法封装在类内部，提升代码的整洁度和可读性

```python title="静态方法示例"
class A:
    class_attr = 42  # 类属性：属于类本身，所有实例共享这个属性
    def __init__(self, value):
        # 实例初始化方法：创建实例时自动调用
        self.instance_attr = value  # 实例属性：每个实例拥有自己的独立属性
        
    @staticmethod
    def myadd(a, b):  # 静态方法：没有隐式传入 self 或 cls 参数
         # 只能访问传递进来的参数，不能直接访问类或实例属性 
        return a + b  # 返回两个参数的和（不涉及类或实例属性）
        
# 创建类 A 的一个实例对象 a，并传入值 10 给 __init__ 方法
a = A(10)
# 调用静态方法 myadd，通过类名 A 访问
print(A.myadd(100, 200))  # 输出: 300
# 同样调用静态方法 myadd，这次通过实例 a 访问
print(a.myadd(300, 400))  # 输出: 700
```


**易错点**： &#x20;

忘记添加@staticmethod装饰器，此时方法会被当作实例方法，调用时报错(缺少self 参数)

试图在静态方法中直接访问self或cls，会报错(未定义该变量)

```python title="完整示例代码"
class BankAccount:
    # 类属性：存款利率（所有账户共享）
    interest_rate = 0.05
    
    def __init__(self, balance):
        # 实例属性：账户余额（每个账户独有）
        self.balance = balance
        
    # 实例方法：计算利息（依赖实例属性balance）
    def apply_interest(self):
        self.balance *= (1 + BankAccount.interest_rate)
        
    # 类方法：修改存款利率（依赖类属性interest_rate）
    @classmethod
    def set_interest_rate(cls, rate):
        cls.interest_rate = rate
        
    # 静态方法：验证金额合法性（与类、实例无关，仅处理传入参数）
    @staticmethod
    def validate_amount(amount):
        # 逻辑：金额必须是正数，且为数字类型
        if not isinstance(amount, (int, float)):
            print("金额必须是数字类型")
            return False
        if amount <= 0:
            print("金额必须大于0")
            return False
        return True
    # 静态方法：工具计算（两数相加，完全独立）
    @staticmethod
    def add(a, b):
        return a + b

# 类名调用静态方法（推荐）
print(BankAccount.validate_amount(1000))  # True
print(BankAccount.validate_amount(-500))  # 金额必须大于0；False
print(BankAccount.add(100, 200))  # 300

# 实例对象调用静态方法
acc = BankAccount(1000)
print(acc.validate_amount(500))  # True
print(acc.add(300, 400))  # 700

# 静态方法无法直接访问类属性/实例属性（需手动传递）
# print(interest_rate)  # 报错：name 'interest_rate' is not defined
# 手动传递类名，访问类属性
@staticmethod
def get_interest_rate(cls):
    return cls.interest_rate
print(get_interest_rate(BankAccount))  # 0.05
```


![](image/image_9PwO9lWyp5.png)

**三种方法对比**

![](image/image_iZio4P1rVi.png)

#### 🪻 魔术方法

魔术方法(Magic Method)是 Python 中以双下划线\_\_xx\_\_包裹的特殊方法，无需手动调用，当执行特定操作(如+、print()、len()等)时，Python 会自动调用对应的魔术方法

【作用】让自定义类可以像Python内置类型(如列表、字符串、整数)一样，自然地使用内置操作(+、print()、len()等)，提升类的易用性和灵活性

**显示相关**

****str**(self)：** 定义对象的字符串表示形式，可通过str(object) 或print(object) 调用。例如，可以返回一个字符串，描述对象的属性

```python title="示例"
class Person:
    # 构造方法 __init__：用于初始化 Person 类的实例
    def __init__(self, name, age):
        self.name = name    # 将传入的 name 参数赋值给实例属性 self.name
        self.age = age    # 将传入的 age 参数赋值给实例属性 self.age
    # 定义 __str__ 方法：返回对象的字符串表示，用于 print() 和 str()
    
    def  __str__ (self):
        # 返回一个格式化的字符串，展示人的姓名和年龄
        return f"Person: {self.name}, Age: {self.age}"
        
# 创建 Person 类的一个实例 p，并传入参数 "Alice" 和 30
p = Person("Alice", 30)
# 使用 print() 函数打印对象 p，会自动调用 __str__ 方法
print(p)       # 输出: Person: Alice, Age: 30
```


****repr**(self)：** 定义对象的"官方"字符串表示形式，常用于调试。通过 repr(object) 调用

如果没有定义\_\_str\_\_()，那么\_\_repr\_\_()会被用来替代str()和print()

repr()方法用于返回一个可以用来重新创建对象的字符串，理想情况下，返回的字符串应当是合法的 Python 表达式

```python title="示例"
class Person:
    # 构造方法 __init__：用于初始化 Person 类的实例
    def __init__(self, name, age):
        self.name = name    # 将传入的 name 参数赋值给实例属性 self.name
        self.age = age    # 将传入的 age 参数赋值给实例属性 self.age
        
    # 定义 __repr__ 方法：返回对象的“官方”字符串表示形式
    def  __repr__ (self):
        # 通常用于调试，返回一个可以重新创建该对象的字符串表达式
        return f"Person('{self.name}', {self.age})"
        
# 创建 Person 类的一个实例 p，并传入参数 "Alice" 和 30
p = Person("Alice", 30)
# 使用 repr() 函数输出对象 p 的“正式”字符串表示
# 因为定义了 __repr__ 方法，所以会调用该方法返回格式化的字符串
print(repr(p))  # 输出: Person('Alice', 30)
```


\_\_repr\_\_()是供开发人员使用的，输出的字符串应该尽可能接近于可以创建该对象的代码

在调试时使用repr()更加方便，它提供了一个清晰的对象表示

**运算符重载**

****add**(self, other)：** 定义+运算符的行为

该方法允许重载加法操作符+，使其在两个对象之间执行加法时能够自定义行为

```python title="示例"
class Point:   #定义一个名为 Point 的类，表示二维平面上的一个点
    # 构造方法 __init__：初始化点的 x 和 y 坐标
    def __init__(self, x, y):
        self.x = x    # 将传入的 x 值赋给实例属性 self.x
        self.y = y    # 将传入的 y 值赋给实例属性 self.y
        
    # 定义 __add__ 方法：实现两个 Point 实例之间的加法操作
    def  __add__ (self, other):
        # 创建一个新的 Point 对象，其 x 和 y 分别是两个点对应坐标的和
        return Point(self.x + other.x, self.y + other.y)
        
    # 定义 __repr__ 方法：返回 Point 对象的字符串表示，便于调试
    def __repr__(self):
        # 返回格式为 Point(x, y) 的字符串，展示点的坐标
        return f"Point({self.x}, {self.y})"
        
# 创建第一个 Point 实例 p1，坐标为 (1, 2)
p1 = Point(1, 2)
# 创建第二个 Point 实例 p2，坐标为 (3, 4)
p2 = Point(3, 4)
# 使用 + 运算符将两个 Point 对象相加，底层调用的是 __add__ 方法
p3 = p1  +  p2
# 打印 p3 对象，会自动调用 __repr__ 方法输出其字符串表示
print(p3)  # 输出: Point(4, 6)
```


\_\_\*\*sub \_\_(self, other)：\*\*定义 - 运算符的行为

****lt**(self, other)：** 定义 < 运算符的行为

****gt**(self, other)：** 定义 > 运算符的行为

****eq**()：** 定义 == 运算符的行为

该方法允许自定义对象的相等比较行为，默认情况下，Python 会比较对象的内存地址

```python title="示例"
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def  __eq__ (self, other):
        return self.x == other.x and self.y == other.y 
        
p1 = Point(1, 2)
p2 = Point(1, 2)
print(p1 == p2)  # 输出: True
```


**容器操作**

****getitem**(self, key)：** 定义对象支持索引 \[] 操作

使得对象能够支持类似列表、元组那样的索引操作

```python title="示例"
class MyList:
    def __init__(self, items):
        self.items = items    #将传入的列表items存储为实例的一个属性self.items
        
    # 定义 __getitem__ 方法：允许使用索引访问对象中的元素（如 my_list[index]）
    def  __getitem__ (self, index):
        return self.items[index]    # 返回self.items中指定索引位置的元素
        
# 创建一个 MyList 实例 my_list，并传入一个列表 [1, 2, 3, 4]
my_list = MyList([1, 2, 3, 4])
# 调用 __getitem__ 方法
print(my_list[2])  # 输出: 3
```


****setitem**(self, key, value)：** 定义对象支持索引赋值操作 \[] =

允许定义如何通过索引给对象赋值

```python title="示例"
class MyList:
    def __init__(self, items):
        self.items = items
        
    def  __setitem__ (self, index, value):
        self.items[index] = value
        
my_list = MyList([1, 2, 3])
my_list[1] = 10
print(my_list.items)  # 输出: [1, 10, 3]
```


****delitem**(self, key)：** 定义对象支持索引删除操作del obj\[i]

使对象可像列表或字典一样删除元素

```python title="示例"
class MyList:
    def __init__(self, items):
        self.items = items
    def __delitem__(self, key):
        del self.items[key]
        
my_list = MyList([1, 2, 3])
del my_list[0] 
print(my_list.items)  # Output: [2, 3]
```


****len**(self)：** 定义len()函数的行为

允许自定义len()函数的行为，返回对象的长度

```python title="示例"
class MyList:
    def __init__(self, items):
        self.items = items
    def __len__(self):
        return len(self.items)
        
my_list = MyList([1, 2, 3])
print(len(my_list))  # 输出: 3
```


**迭代器**

****iter**(self)：** 定义迭代器，使对象可迭代，可用于for循环

****next**(self)：** 定义迭代器的下一个元素，通常与\_\_iter\_\_一起使用

```python title="让对象可以被 for 循环"
class MyNumbers:
    def __init__(self, max_num):
        self.max_num = max_num
    def __iter__(self):
        self.current = 1  # 初始化计数器
        return self
    def __next__(self):
        if self.current <= self.max_num:
            num = self.current
            self.current += 1
            return num
        else:
            raise StopIteration  # 结束循环

nums = MyNumbers(3)
for n in nums:
    print(n)    # 输出：1  2  3
```


**可调用对象**

****call**(self, other)：** 是个特殊的方法(也称为"魔法方法")，允许一个对象像函数一样被调用

```python title="示例"
class Adder:
    def __init__(self, base):
        self.base = base
    def __call__(self, x):
        return self.base + x

add5 = Adder(5)
print(add5(10))   # 像函数一样调用
```


**生命周期**

****init**(self, ...)：** 初始化对象，通常用于设置对象的属性

****del**()：** 定义对象的析构方法，通常用于资源清理，这个方法在对象销毁时调用，通常用于清理资源(如关闭文件、数据库连接等)

```python title="示例"
class MyClass:
    def __init__(self, name):
        self.name = name
        print(f"对象 {name} 创建")
    def  __del__ (self):
        print(f"对象 {self.name} 被销毁")
        
obj = MyClass("Test")
del obj  # 输出: 对象 Test 被销毁
```


## ⭐ 面向对象编程(OOP)四大特性

OOP的四大基本特性是封装、继承、多态和抽象

### 🌺 封装(Encapsulation)

封装是将对象的属性(数据)和方法(行为)包装在类内部，对外隐藏具体实现细节，只暴露安全、可控的公共接口(API 接口)供外部访问

**封装的实现方式**

**访问控制**

![](image/image_HKeTfIoRt4.png)

```python title="私有属性与访问接口"
class Dog:
    def __init__(self, name, age):
        self.__name = name  # 私有属性：解释器重命名为 _Dog__name
        self._age = age     # 保护属性：仅约定不直接访问
    
    # 公共接口：读取私有属性
    def get_name(self):
        return self.__name
    
    # 公共接口：修改私有属性（可添加验证逻辑）
    def set_name(self, new_name):
        if isinstance(new_name, str) and new_name.strip():
            self.__name = new_name
        else:
            raise ValueError("名字必须是非空字符串")

# 使用示例
dog = Dog("泰迪", 2)
print(dog.get_name())   # 正确：通过接口访问 → 泰迪
# print(dog.__name)     # 错误：直接访问私有属性会报错
dog.set_name("金毛")     # 正确：通过接口修改
print(dog.get_name())   # 输出：金毛
```


🩷 **属性装饰器@property**

属性装饰器用于将类的方法转换为只读属性，使方法可以像属性一样访问，不需用 () 调用

| 场景     | 实现方式                 | 示例                               |
| ------ | -------------------- | -------------------------------- |
| 只读属性   | @property            | p.name（无括号）                      |
| 可读可写属性 | @property + @setter  | p.name = "Bob"                   |
| 可读可删属性 | @property + @deleter | del p.name                       |
| 计算属性   | @property（动态计算）      | c.area（每次计算）                     |
| 私有属性保护 | \ \_\_ 前缀 + 公共方法     | self.\ \_\_ name 通过get\_name()访问 |

```python title="基本用法（使用 @property 使方法变为只读属性）"
class Person:
    def __init__(self, name):
        self._name = name  # 单下划线：约定为保护属性
    @property
    def name(self):        # 方法变为属性
        return self._name
        
p = Person("Alice")
print(p.name)          # 无需括号，像属性一样访问
 p.name = "Bob"          # 报错：只读属性不可修改
```


如果希望属性可以修改，需要使用 @property 结合 @属性名.setter：

```python title="可读可写（通过 @属性名.setter 装饰器添加写权限）"
class Person:
    def __init__(self, name):
        self._name = name
    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, new_name):  # 方法名必须与@property装饰的方法名一致
        if isinstance(new_name, str) and new_name.strip():
            self._name = new_name
        else:
            raise ValueError("名字必须是非空字符串")
            
p = Person("Alice")
p.name = "Bob"              # 可修改，会触发setter方法
```


如果希望属性支持删除，可使用@属性名.deleter：

```python title="可读可删（通过 @属性名.deleter 装饰器添加删除权限）"
class Person:
    def __init__(self, name):
        self._name = name
    # 使用@property装饰器定义name属性的getter方法
    @property     
    def name(self):
        # 当访问 p.name 时会自动调用这个方法
        return self._name    
    @name.deleter
    # 使用@属性名.deleter装饰器定义name属性的deleter方法
    def name(self):          # 删除属性时触发
        # 当执行 del p.name 时会调用这个方法
        print("删除 name 属性")
        del self._name       # 真正删除底层的 _name 属性
        
p = Person("Alice")
# 使用 del 语句删除p对象的name属性，这会触发@name.deleter定义的方法
del p.name       # 触发deleter方法，输出提示信息并删除_name属性
```


![](image/image_EY90J9uM7c.png)

@property 适用于需要动态计算的属性：

```python title="计算属性：用于动态计算的属性，无需存储在实例中"
class Circle:
    def __init__(self, radius):
        self._radius = radius
    @property
    def area(self):
        # 每次访问c.area都会重新计算，无需手动调用方法
        return 3.14 * self._radius **2

c = Circle(10)
print(c.area)  # → 314.0（无需加括号）
c._radius = 5
print(c.area)  # → 78.5（自动重新计算）
```


子类可以重写父类的 @property 方法，实现自定义逻辑：

```python title="@property 在继承中的应用"
class Animal:
    def __init__(self, name):
        self._name = name
    @property
    def name(self):
        return f"Animal: {self._name}"
        
class Dog(Animal):
    @property
    def name(self):          # 重写父类的property
        return f"Dog: {self._name}"
        
dog = Dog("Buddy")
print(dog.name)            # 输出：Dog: Buddy
```


**封装的注意事项**

不要滥用@property：仅在需要验证、计算或隐藏逻辑时使用，简单属性直接用公有/保护属性

避免在@property中执行耗时操作(如数据库查询)，否则每次访问都会消耗性能

Python 的私有属性是"伪私有"(\_类名\_\_属性名)，禁止直接通过此方式访问，违反封装原则

### 🌻 继承(Inheritance)

继承是从已有的父类(基类/超类)派生出子类(派生类)，子类自动拥有父类的所有属性和方法，同时可扩展新功能或重写原有功能

![](image/image_SaYPfeAtG2.png)

核心目标：代码复用+功能扩展

底层逻辑：Python 中所有类最终都继承自object类（默认隐式继承）

```python title="基本语法"
# 单继承（最常用）
class 子类(父类):
    # 子类的新增属性/方法

# 多继承（慎用：可能引发方法解析顺序问题）
class 子类(父类1, 父类2):
    # 子类的属性/方法
```


**基础派生**   // 继承+新增功能

最常用的派生方式：子类继承父类的所有公有/保护成员，同时添加自己的属性/方法

```python title="基础派生代码示例"
class Animal:
    # 父类的构造方法：初始化通用属性
    def __init__(self, name, age):
        self._name = name  # 保护属性：子类可访问，外部不建议直接访问
        self._age = age    # 保护属性
    # 父类的通用方法
    def eat(self):
        print(f"{self._name} 正在进食")
    # 父类的“待重写”方法
    def speak(self):
        print(f"{self._name} 发出叫声")

# 子类（派生类）：Dog派生于Animal
class Dog(Animal):
    # 子类的构造方法：先复用父类逻辑，再添加子类特有属性
    def __init__(self, name, age, breed):  # breed：品种（子类新增属性）
        # 第一步：调用父类的__init__，初始化继承的属性
        super().__init__(name, age)  # 等价于Animal.__init__(self, name, age)
        # 第二步：添加子类特有属性
        self._breed = breed  # 狗的品种（如“金毛”“泰迪”）
    # 重写父类方法：覆盖原有逻辑（多态的基础）
    def speak(self):
        print(f"{self._name}（{self._breed}）汪汪叫")
    # 新增子类特有方法：父类没有的功能
    def wag_tail(self):
        print(f"{self._name} 开心地摇尾巴")

# 测试派生类
dog = Dog("旺财", 3, "金毛")
dog.eat()          # 继承父类方法 → 旺财 正在进食
dog.speak()        # 重写父类方法 → 旺财（金毛）汪汪叫
dog.wag_tail()     # 子类新增方法 → 旺财 开心地摇尾巴
print(dog._age)    # 访问继承的保护属性 → 3
```


子类可直接访问父类的保护属性(*xxx)，但不能直接访问私有属性(* *xxx)(如父类self.* \_name)

子类构造方法中，必须先通过super().\_\_init\_\_()调用父类构造方法，否则父类的属性(如\_name)无法初始化

**方法重写/覆盖**（Override）

派生的核心价值之一是"重写父类方法"—— 在不修改父类代码的前提下，让子类拥有自定义行为，这也是多态的基础

> 重写的规则：
>
> 方法名必须与父类完全一致
>
> 参数列表建议与父类一致（Python 不强制，但可提高代码可读性）
>
> 子类方法的功能应符合父类方法的语义（遵循里氏替换原则）

```python title="重写父类的魔术方法"
class Person:
    def __init__(self, name):
        self._name = name
    # 父类的__str__方法
    def __str__(self):
        return f"Person: {self._name}"

# 派生类：Student派生于Person
class Student(Person):
    def __init__(self, name, student_id):
        super().__init__(name)
        self._student_id = student_id
    # 重写__str__方法：自定义字符串输出
    def __str__(self):
        return f"Student: {self._name}（学号：{self._student_id}）"

# 测试
p = Person("张三")
print(p)  # → Person: 张三（父类逻辑）
s = Student("李四", "2024001")
print(s)  # → Student: 李四（学号：2024001）（子类重写逻辑）
```


子类重写父类方法后，若想在子类方法中复用父类的逻辑，可通过super()或父类名.方法名()调用

```python title="调用父类被重写的方法"
class Animal:
    # 父类的构造方法：初始化通用属性
    def __init__(self, name, age):
        self._name = name  # 保护属性：子类可访问，外部不建议直接访问
        self._age = age    # 保护属性
    # 父类的“待重写”方法
    def speak(self):
        print(f"{self._name} 发出叫声")
        
class Cat(Animal):
    def speak(self):
        # 第一步：调用父类的speak方法（复用原有逻辑）
        super().speak()  # → 咪咪 发出叫声
        # 第二步：添加子类自定义逻辑
        print(f"{self._name} 补充喵喵叫")

cat = Cat("咪咪", 2)
cat.speak()

```


![](image/image_INXqfVcn2Y.png)

**多层派生(继承链)**

子类还可以作为父类，派生出新的子类，形成"继承链"(但建议不超过3层)

```python title="示例代码"
# 顶级父类：Animal
class Animal:
    def __init__(self, name, age):
        self._name = name  # 保护属性：子类可访问，外部不建议直接访问
        self._age = age    # 保护属性
    def eat(self):
        print(f"{self._name} 正在进食")
    def speak(self):
        print(f"{self._name} 发出叫声")
        
# 一级派生：Dog（派生于Animal）
class Dog(Animal):
    def __init__(self, name, age, breed):  # breed：品种（子类新增属性）
        super().__init__(name, age)
        self._breed = breed 
    def speak(self):
        print(f"{self._name}（{self._breed}）汪汪叫")
    def wag_tail(self):
        print(f"{self._name} 开心地摇尾巴")
        
# 二级派生：GuideDog（导盲犬，派生于Dog）
class GuideDog(Dog):
    def __init__(self, name, age, breed, level):
        # 调用父类Dog的构造方法
        super().__init__(name, age, breed)
        # 新增属性：训练等级
        self._level = level
    # 新增特有方法：导盲功能
    def guide(self):
        print(f"{self._name}（{self._breed}）引导主人行走，训练等级：{self._level}")

guide_dog = GuideDog("小七", 4, "拉布拉多", "高级")
guide_dog.eat()          # 继承自Animal → 小七 正在进食
guide_dog.speak()        # 继承自Dog → 小七（拉布拉多）汪汪叫
guide_dog.wag_tail()     # 继承自Dog → 小七 开心地摇尾巴
guide_dog.guide()        # 子类特有 → 小七（拉布拉多）引导主人行走，训练等级：高级
```


**多派生(多继承)**

一个子类同时派生于多个父类（慎用！容易引发方法冲突）

当多个父类有同名方法时，按"从左到右、深度优先"的顺序查找方法(可用类名.\_\_mro\_\_查看)

```python title="示例代码"
# 父类1：SwimMixin（混合类，提供游泳功能）
class SwimMixin:
    def swim(self):
        print(f"{self._name} 正在游泳")

# 父类2：FlyMixin（混合类，提供飞行功能）
class FlyMixin:
    def fly(self):
        print(f"{self._name} 正在飞行")

# 子类：Duck 同时派生于 Animal、SwimMixin、FlyMixin
class Duck(Animal, SwimMixin, FlyMixin):
    def speak(self):
        print(f"{self._name} 嘎嘎叫")

duck = Duck("唐老鸭", 1)
duck.eat()   # 继承自Animal → 唐老鸭 正在进食
duck.speak() # 重写父类 → 唐老鸭 嘎嘎叫
duck.swim()  # 继承自SwimMixin → 唐老鸭 正在游泳
duck.fly()   # 继承自FlyMixin → 唐老鸭 正在飞行
```


**抽象派生**     // 强制子类实现方法

通过抽象类派生子类，强制子类必须实现指定方法（保证接口一致性）

```python title="示例代码"
from abc import ABCMeta, abstractmethod

# 抽象父类：所有派生类必须实现calculate方法
class Shape(metaclass=ABCMeta):
    @abstractmethod
    def calculate_area(self):
        pass  # 无实现，仅定义接口

# 派生类1：Circle（必须实现calculate_area）
class Circle(Shape):
    def __init__(self, radius):
        self._radius = radius
    def  calculate_area (self):
        return 3.14 * self._radius **2

# 派生类2：Square（必须实现calculate_area）
class Square(Shape):
    def __init__(self, side):
        self._side = side
    def  calculate_area (self):
        return self._side ** 2

circle = Circle(10)
print(circle.calculate_area())  # → 314.0
square = Square(5)
print(square.calculate_area())  # → 25
```


**练习**

![](image/image_0ryD_F5cwW.png)

```python title="参考代码"
class Bicycle:
    def  run (self, km):
        print(f"自行车骑行了 {km} 公里")
        
class EBicycle(Bicycle):
    def __init__(self, volume=0):  # 初始化电量，默认0
        self.volume = volume
        
    def fill_charge(self, vol):  # 充电方法
        self.volume += vol
        print(f"已充电 {vol} 度，当前电量: {self.volume} 度")
        
    def run(self, km):  # 覆盖父类的run方法
        # 计算电池可行驶的公里数（每10km消耗1度电）
        e_km = min(km, self.volume * 10)
        if e_km > 0:
            self.volume -= e_km / 10  # 消耗电量
            print(f"电动车使用电池骑行了 {e_km} 公里，剩余电量: {self.volume} 度") 
        # 计算剩余需要用脚蹬的公里数
        if km > e_km:
            foot_km = km - e_km
            super(). run (foot_km)  # 调用父类的run方法
            
    def fill_charge(self, vol):
        print("电动自行车充电", vol, "度")
        self.volume += vol
        
b = EBicycle(5)  # 新买的电动车内有5度电
b.run(10)  # 电动骑行了10km 还剩 4度电
b.run(100)  # 电动骑行了 40 km ，还剩 0 度电, 用脚登骑行了60km
b.fill_charge(10)  # 电动自行车充电 10 度
b.run(50)  # 骑行了50公里剩余 5度电
```


![](image/image_DLo24q5-mC.png)

### 🌵 多态(Polymorphism)

多态是指同一接口(方法名)在不同对象上表现出不同的行为，核心是"动态绑定"(运行时根据对象实际类型决定调用哪个方法)

多态的实现通常通过继承和方法重写来实现

**基于继承的多态**

动态绑定：Python 在运行时根据对象的实际类型决定调用哪个方法，而非编译时

```python title="同一接口，不同行为"
class Animal:  # 基类
    def speak(self):
        print("Animal is speaking")
class Dog(Animal):  # 子类，继承自Animal
    def  speak (self):  # 重写父类的speak方法
        print("Woof!")
class Cat(Animal):  # 另一个子类
    def  speak (self):  # 重写父类的speak方法
        print("Meow!")
        
# 定义统一接口函数（不关心参数类型，只要求有speak方法）      
def animal_speak(animal):  # 统一接口函数
    animal. speak ()  # 运行时动态绑定：调用对象实际的speak方法
# 创建实例
dog = Dog()
cat = Cat()
# 同一接口，不同行为
animal_speak(dog)  # 输出：Woof!
animal_speak(cat)  # 输出：Meow!
```


**方法重写**

如果父类方法的功能不能满足需求，可以在子类重写父类的方法

方法签名必须相同：方法名、参数列表、返回值类型需与父类一致

访问权限不能更严格：子类方法的访问权限需大于等于父类

**运算符重载**（多态的特殊形式）

通过重写魔术方法，让自定义类支持 Python 内置运算符(如+、-、 \*)，本质是"同一运算符接口，不同实现逻辑"

![](image/image_0XKxmBu3Dv.png)

```python title="示例代码"
class MyNumber:
    def __init__(self, value):
        self.data = value
    # 重载加法运算符 +
    def __add__(self, other):
        return MyNumber(self.data + other.data)
    # 重载减法运算符 -
    def __sub__(self, other):
        return MyNumber(self.data - other.data)
    # 重载字符串输出（便于打印）
    def __str__(self):
        return f"MyNumber({self.data})"

n1 = MyNumber(100)
n2 = MyNumber(200)
print(n1 + n2)  # → MyNumber(300)（调用__add__）
print(n1 - n2)  # → MyNumber(-100)（调用__sub__）
```


```python title="算术运算符重载示例"
class MyNumber:
    """此类用于定义一个自定义的类，用于演示运算符重载"""
    # 构造函数 __init__：用于初始化 MyNumber 类的实例
    def __init__(self, value):
        # 将传入的值赋给实例属性 self.data，表示该对象存储的数据
        self.data = value
    # 定义 __str__ 方法：用于返回对象的字符串表示，便于打印
    def __str__(self):
        # 返回格式为 "MyNumber(值)" 的字符串
        return "MyNumber(%d)" % self.data
        
    # 定义 __add__ 方法：实现加法运算符重载
    def __add__(self, rhs):
        """加号运算符重载"""    # 当使用 + 运算符时，此方法会被调用
        print("__add__ is called")  # 提示信息，表示调用了加法方法
        # 创建一个新的 MyNumber 对象，其值为两个对象的 data 相加
        return MyNumber(self.data + rhs.data)
        
    # 定义 __sub__ 方法：实现减法运算符重载
    def __sub__(self, rhs):
        """减号运算符重载"""    # 当使用 - 运算符时，此方法会被调用
        print("__sub__ is called")  # 提示信息，表示调用了减法方法
        # 创建一个新的 MyNumber 对象，其值为两个对象的 data 相减
        return MyNumber(self.data - rhs.data)
        
# 创建两个 MyNumber 实例对象 n1 和 n2，分别传入值 100 和 200
n1 = MyNumber(100)
n2 = MyNumber(200)
print(n1 + n2)  # 用+将n1和n2相加，自动调用__add__方法，返回一个新的MyNumber对象
n = n1 - n2  # 用-将n1和n2相减，会自动调用__sub__方法，返回一个新的MyNumber对象赋给n
print(n.data)  # 打印新对象n的data属性（即 100 - 200 = -100）
```


![](image/image_ucp1TEX5Wc.png)

**常用魔术方法重载**（实现多态）

![](image/image_Hf3dy7sK3X.png)

```python title="str 方法"
class MyNumber:
    def __init__(self, value):
        self.data = value
    def __str__(self):
        return "%s" % self.data  # 返回数据的字符串形式
        
n1 = MyNumber("一只猫")
print(str(n1))  # 输出: 一只猫
```


```python title="代码示例"
class MyList:
    def __init__(self, iterable=()):
        self.data = list(iterable)
    def __len__(self):
        print("__len__ 被调用")
        return len(self.data)  # 返回内部列表的长度
    def __abs__(self):
        return MyList([abs(x) for x in self.data])  # 返回元素绝对值的新列表
        
myl = MyList([1, -2, 3, -4])
print(len(myl))  # 输出: __len__ 被调用\n 4
print(abs(myl).data)  # 输出: [1, 2, 3, 4]
```


### 🧊 抽象(Abstraction)

—— 与之前的抽象派生知识点相同

抽象是从具体事物中提取共性特征，忽略无关细节，形成抽象类/接口，规定"必须实现的方法"，但不提供具体实现

**抽象的实现方式**

Python 通过abc模块的ABCMeta和abstractmethod实现抽象类

```python title="示例代码"
from abc import ABCMeta, abstractmethod

# 抽象类：定义接口，不提供实现
class Animal(metaclass=ABCMeta):
    def __init__(self, name):
        self._name = name
    # 抽象方法：强制子类实现
    @abstractmethod
    def speak(self):
        pass  # 无具体实现

# 子类必须实现speak方法，否则无法实例化
class Dog(Animal):
    def speak(self):
        print(f"{self._name} 汪汪叫")

class Cat(Animal):
    def speak(self):
        print(f"{self._name} 喵喵叫")

# 使用示例
dog = Dog("旺财")
dog.speak()  # → 旺财 汪汪叫
# 错误示例：抽象类无法实例化
 animal = Animal("动物")   
# 报错：Can't instantiate abstract class Animal with abstract method speak
```


抽象方法仅定义"做什么"，不定义"怎么做"，具体实现由子类完成

## ⭐ SUPER函数

super() 是Python专门用来调用父类(超类)方法的内置函数 → super() = 找到父类→调用父类的方法

作用只有两个：

1. 在子类中调用被覆盖的父类方法
2. 在子类构造方法中调用父类构造方法 \_\_init\_\_

#### super() 的两种写法

**无参数**（最常用、推荐）

```python title="在子类内部直接用"
super().方法名(参数)
```


自动识别当前类、当前对象，最简洁

```python title="示例代码"
class A:
    def add(self, x):
        print(f"A.add: {x + 1}")
# B是A的子类
class B(A):
    def add(self, x):
        print("B.add: 子类方法")
        super().add(x)  # 调用父类 A 的 add

b = B() 
b.add(2)
```


![](image/image__eXN3hxktl.png)

**带参数**（老式写法，用于外部调用）

```python title="格式"
super(子类名, 子类对象).方法()
```


作用：在类外部，强行调用父类被覆盖的方法

```python title="示例代码"
class Parent:
    def myMethod(self):
        print('调用父类方法')

class Child(Parent):
    def myMethod(self):
        print('调用子类方法')

c = Child()
c.myMethod()                # 调用子类
super(Child, c).myMethod()  # 强制调用父类
```


![](image/image_InU-dMzDHu.png)

#### super ().\_\_**init**\_\_()

通过super().\_\_init\_\_()调用父类构造函数，以确保父类的构造函数被正确调用和初始化

避免代码重复：父类的初始化逻辑只需写一次

多继承安全：确保所有父类的初始化方法按 MRO 顺序被调用

正确初始化：确保父类的初始化逻辑(如设置属性、分配资源等)被执行

```python title="初始化父类属性"
class Parent:
    def __init__(self):
        print("Parent 初始化")
        self.parent_attr = "父类属性"

class Child(Parent):
    def __init__(self):
        super().__init__()  # 调用父类构造
        print("Child 初始化")
        self.child_attr = "子类属性"

child = Child()
print(child.parent_attr)  # 能访问父类属性
```


![](image/image_aPmVkifyTb.png)

子类必须写 super ().\_\_init\_\_()，否则父类的\_\_init\_\_不会执行，父类属性就不存在

#### MRO方法解析顺序

当一个类继承多个父类时：Python 必须知道调用方法时，先找哪个父类，这个查找顺序就叫MRO(Method Resolution Order)方法解析顺序

\*\*MRO 的计算规则 \*\*— Python使用C3线性化算法计算MRO

子类优先于父类：子类的方法或属性会优先于父类被查找

父类的顺序保持不变：在定义类时，父类的顺序会影响 MRO。在多重继承中，按照继承列表的顺序从左到右查找，继承列表中左边的父类优先于右边

单调性：如一个类出现在另一个类的MRO中，那么它的父类也应出现在这个类的MRO中

最终都会到 object

**MRO 查看**

```python title="查看 MRO"
类名 .__mro__
 或 
 类名 .mro()
```


```python title="示例代码"
class A: pass
class B(A): pass
class C(A): pass
class D(B, C): pass
# 查看mro
print(D.__mro__)    # 输出顺序：D → B → C → A → object
```


![](image/image_EVElTWGHcV.png)

解说：先找自己 D，再找左边父类 B，再找右边父类 C，再找 B、C 父类 A，最后顶级父类 object

**MRO冲突**

```python title="多继承报错的根本原因：MRO 顺序冲突"
class A:
    def method(self):
        print("A.method")
class B(A):
    def method(self):
        print("B.method")
class C(A):
    def method(self):
        print("C.method")
class D(B, C):
    def method(self):
        print("D.method")
class E(C, B):
    def method(self):
        print("E.method")
class F(D, E):
    pass
# 查看 F 类的 MRO
print(F.__mro__)
```


![](image/image_3eQ5tcCTfH.png.mark.png)

![](image/image_5XamfxDC_M.png)

原因：D的顺序(B优先于C)  E的顺序(C优先于B) → Python无法统一顺序：冲突报错

在这种情况下，Python无法创建一个一致的方法解析顺序(MRO) → 解决办法：类D和E继承B、C的顺序一致，即：

```python title="解决办法"
class D(B, C):
    def method(self):
        print("D.method")
class E(B, C):
    def method(self):
        print("E.method")
```


# 迭代器和生成器

## ⭐ 迭代器Iterator

迭代器 = 不占内存的、按需取数的遍历工具

迭代器提供了一种惰性(lazy evaluation)获取数据的方法，使得我们能够逐步访问序列中的元素，而无需一次性加载所有数据。其主要优点包括节省内存、提高性能、支持自定义遍历逻辑等。

> 为什么要用迭代器？→ 传统容器(列表/元组/字典)的痛点
>
> 传统容器一次性把所有数据加载进内存，数据量大时占内存、卡顿、效率低
>
> 无法表示无限序列（如无限自然数）

**迭代器的核心优势**

惰性计算：用到才生成，不占大量内存

内存高效：处理百万/亿级数据不卡顿

统一遍历接口：for循环可直接遍历

支持自定义遍历规则（文件、数据流、数据库）

#### 迭代器协议(Iterator Protocol)

迭代器的实现需要遵循特定协议，必须包含两个关键方法：\_\_iter\_\_( ) 和 \_\_next\_\_( )&#x20;

\_\_iter\_\_( )：返回迭代器自身，让对象可被for循环遍历

\_\_next\_\_( )：返回下一个元素，如果没有更多元素，则抛出StopIteration异常

可迭代对象(Iterable) VS迭代器：

可迭代对象 → iter() → 迭代器

![](image/image_SSopnIegNW.png)

#### **迭代器的创建**

```python title="步骤 1：获取迭代器"
迭代器对象  = iter( 可迭代对象 )      # 用iter函数可以返回一个可迭代对象的迭代器
```


```python title="步骤 2：手动取值"
next( 迭代器对象 )
```


```python title="步骤 3：循环遍历"
for 变量 in  迭代器对象 :
    处理数据
```


迭代器只能向前取值，一旦元素被读取，就无法回头重新获取(除非重新创建迭代器)

🧀**基础迭代器**（列表转迭代器）

```python title="示例1  可迭代对象"
l1 = [1,2,3,4,5,6]
print("l1:",l1)

# 把l1转换成可迭代对象
iter_l1 =  iter (l1)  # 列表l1是可迭代对象，通过iter(l1)将其转换为迭代器iter_l1
print("iter_l1:",iter_l1)

# 手动调用next()逐个取值
print(next(iter_l1))  # 输出 1
print(next(iter_l1))  # 输出 2
print(next(iter_l1))  # 输出 3

# for循环自动遍历剩余元素 -> for循环自动捕获StopIteration并停止
for i in iter_l1:
    print(i)  # 输出 4、5、6
```


![](image/image_OdcU5jDKhc.png)

🧀**range 迭代器**

range是Python内置的可迭代对象(不是列表、不是元组)，用于生成一个整数等差数列，它采用惰性计算，只在需要时才生成数字，极度节省内存

```python title="示例 2：range 迭代器"
# 创建迭代器
it = iter(range(1, 10, 3))
# 逐个取值
print(next(it))  # 1
print(next(it))  # 4
print(next(it))  # 7
```


🧀**自定义迭代器**（文件遍历）

```python title="示例 3：自定义迭代器（文件遍历）"
import os

class DataLoader:
    # 初始化：传入文件列表，设置索引从0开始
    def __init__(self, filelist):
        self.filelist = filelist
        self.index = 0
    # 迭代器协议1：返回自身
    def __iter__(self):
        return self
    # 迭代器协议2：next核心逻辑
    def __next__(self):
        if self.index < len(self.filelist):
            # 取出当前文件
            current_file = self.filelist[self.index]
            # 索引向后移动
            self.index += 1
            return current_file
        else:
            # 迭代结束，抛出异常
            raise StopIteration

# 使用
filelist = os.listdir('./day04')
datasets = DataLoader(filelist)
# 打印 datasets 实例对象的信息（会显示对象内存地址等信息）
print(datasets)
# 手动取值
print(next(datasets))
print(next(datasets))
# 循环取值
for file in datasets:
    print(file)
```


![](image/QQ_1774358800933_bgSq6rvCff.png.mark.png)

#### 注意事项

- 迭代器只能向前，不能后退：取过的数据无法回头，必须重新创建迭代器
- 迭代器一次性使用：遍历完后就空了，再次next会报错
- 不要多次赋值同一个迭代器：多个变量指向同一迭代器，会互相影响
- for循环会自动捕获StopIteration：所以不会崩溃
- 迭代器本身也是可迭代对象：因为它实现了\_\_iter\_\_

## ⭐ 生成器Generator

生成器 = 极简写法 + 惰性迭代 + 状态保存

生成器是一种特殊的迭代器，通过函数定义，用yield语句生成值。生成器可以自动实现迭代协议，无需手动实现 \_\_iter\_\_( ) 和 \_\_next\_\_( )

> 为什么要用生成器 → 传统方式的痛点
>
> 列表/容器一次性加载所有数据，占内存、易卡顿
>
> 自定义迭代器需要写\_\_iter\_\_、\_\_next\_\_，代码繁琐
>
> 大数据、大文件、无限序列无法高效处理

**生成器的核心优势**

极简代码：不用写迭代器协议，自动实现\_\_iter\_\_和\_\_next\_\_

惰性计算：用到才生成，内存占用极低

状态保留：yield 暂停执行，下次调用从断点继续

高效优雅：代码量少、性能高

#### 生成器原理

生成器本质是特殊迭代器，函数中只要出现yield，就变成生成器函数

调用函数不会执行代码，只返回生成器对象

next( ) 触发执行，遇到yield暂停并返回值，下次next( )从暂停处继续执行

函数结束时自动抛出StopIteration

**执行流程**（important）

调用生成器函数 → 返回生成器对象 →不执行代码

next () → 运行到 yield → 返回值 →暂停

next () → 从暂停处继续 → 再到 yield → 暂停 ...&#x20;

函数结束 → 自动 StopIteration

### 生成器的创建

#### 生成器函数

🌱 **基础生成器函数**

定义函数 → 使用yield 返回数据 → 调用函数得到生成器对象 → 使用next()或for 循环遍历

```python title="示例代码"
# 定义生成器函数
def my_generator():
    print("Start")
    yield 1       # 暂停，返回 1
    print("Continue")
    yield 2       # 暂停，返回 2
    print("End")
    yield 3       # 暂停，返回 3

# 创建生成器对象（不执行代码）
gen = my_generator()
# 遍历生成器
for val in gen:
    print(val)
```


![](image/QQ_1774360328889_QJf9oHQtAK.png.mark.png)

🌱 **带参数的生成器**（帧生成模拟）

```python title="示例代码"
def my_generator(n):
    i = 0
    while True:
        i += 1
        yield f'第{i}帧画面'  # 每次生成一帧
        if i >= n:
            break

# 创建生成器，最多生成5帧
camer = my_generator(5)
for i in camer:
    print(i)
```


![](image/image_RhfIIHnS4u.png)

🌱 **大文件读取**（最实用）

```python title="示例代码"
import os
# 逐行读取超大文件，不占内存
def open_large_file(fn):
    current_dir = os.path.dirname(__file__)
    file_path = os.path.join(current_dir, fn)
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            yield line    # 一次只返回一行

data = open_large_file("log.txt")
print(next(data))   # 读取第一行
print(next(data))   # 读取第二行

```


![](image/image_rjmlnSyuG6.png)

#### **生成器表达式**

生成器可以用表达式形式定义，类似列表推导式，但使用小括号 ( )&#x20;

```python title="生成器表达式（简洁写法）"
(表达式 for 变量 in  可迭代对象  if  条件 )
```


```python title="示例代码"
# 列表推导式（占内存）👎🏻
[x**2 for x in range(5)]

# 生成器表达式（惰性）
gen_expr = (x**2 for x in range(5))
print(next(gen_expr))  # 0
print(next(gen_expr))  # 1
print(next(gen_expr))  # 4
```


**练习：** 代码实现斐波那契数列（最少十个数）

```python title="示例代码"
def fibonacci(n):
    a, b = 0, 1     # 初始化两个变量a和b，分别为0和1
    for _ in range(n):    # 循环n次
        yield b        # 生成当前的斐波那契数b
        a, b = b, a + b        # 更新a和b的值，a变为原来的b，b变为原来的a加b
        
# 调用fibonacci函数生成一个包含前10个斐波那契数的生成器
fib_seq = fibonacci(10)
# 遍历生成器中的每个斐波那契数，并打印出来，数字之间用空格分隔
for i in fib_seq:
    print(i, end=" ")
```


![](image/image_oWocbK8emg.png)

### 注意事项

- 生成器只能遍历一次：遍历完就空了，必须重新创建
- 调用生成器函数不执行代码：只有next( ) 才会执行
- yield不是return：return 结束函数，yield暂停+保留状态
- 生成器无法索引/切片：不能用gen\[0]，只能逐个取
- 不要在生成器中用return返回值：return 会直接触发 StopIteration

# 类型注解Type Hinting

类型注解(Type Hinting)是 Python 3.5+ 引入的、用于给变量、函数参数、返回值标注数据类型的语法，它不影响程序运行，仅用于提升代码可读性和支持静态类型检查

类型注解 = 代码说明书 + 静态防错工具

> 为什么要用类型注解 → Python 动态类型的痛点
>
> 代码复杂后不知道变量/参数是什么类型
>
> 传参错误、返回值用错运行时才报错
>
> 团队协作、大型项目维护成本极高，IDE 无法智能提示，开发效率低

**类型注解的核心优势**

代码自解释：一眼看懂参数/返回值类型

提前排错：静态检查工具(mypy)运行前发现类型错误

IDE智能提示：自动补全、语法提示更精准

大型项目必备：提升可维护性、降低协作成本

**工作原理**

类型注解只是注释：Python 解释器不会强制检查，运行时完全忽略

注解信息存储在 \_\_annotations\_\_ 属性中

依靠第三方工具(mypy、PyCharm、VS Code)实现静态检查

不改变代码运行逻辑，不影响性能

Python 3.9+ 支持原生list/dict/tuple 注解，无需导入 typing

### ⭐ 标准用法

#### 变量注解 ❄️

```python title="语法"
变量名: 类型 = 值
```


支持的基础类型

![](image/image_T7fEJ-gJBB.png)

```python title="示例代码"
# 每一行都明确告诉人和工具：这个变量是什么类型
# Python运行时不检查、不报错，只做提示用，IDE会根据注解提供智能提示
age: int = 18            # 整数类型注解
height: float = 1.75     # 浮点数类型注解
name: str = "小明"        # 字符串类型注解
is_student: bool = True   # 布尔类型注解
nothing: None = None      # 空值类型注解
# 打印查看（运行完全正常）
print(age, height, name, is_student)
```


#### 函数注解 🧊

给函数参数+返回值标类型，一眼看懂函数怎么用、传什么、返回什么

函数注解是Python 3引入的特性，允许在函数定义时为参数和返回值添加类型说明。注解本身不会影响函数的执行(Python 解释器不会强制检查类型)，但能为开发者和工具(如 IDE、类型检查器)提供清晰的类型提示

```python title="语法"
def 函数名(参数1: 类型, 参数2: 类型) -> 返回值类型:    # 无返回值: -> None
    函数体
```


**基础函数注解**

```python title="示例代码"
# 函数参数：x(int), y(int)
# 函数返回：int
def add(x: int, y: int) -> int:
    return x + y
# 正确调用
result = add(3, 5)
print(result)  # 输出8
# 错误调用（类型不匹配）
 add("3", 5)     # mypy会检查报错
```


![](image/image_wQ7uQMmJaa.png)

**变长参数的注解**

变长参数包括位置变长参数(*args)和关键字变长参数(* \*kwargs)，注解需指定参数内部元素的类型

```python title="示例代码"
# 定义一个函数multiply，接受任意数量的整数参数，并返回一个整数
def multiply( *args: int ) -> int:  
    result = 1  
    for num in args:  # 遍历所有传入的参数
        result *= num  # 将每个参数乘到结果上
    return result  # 返回最终的结果
    
# 定义一个函数user_info，接受一个字符串参数name和任意数量的关键字参数kwargs
def user_info(name: str,  **kwargs: str ) -> None:  
    print(f"User: {name}, Details: {kwargs}")  # 打印用户名和详细信息
```


**函数作为参数的注解**\*\*（****Callable****）\*\*

当函数的参数是另一个函数时，需使用typing.Callable 注解函数类型，语法为Callable\[\[参数类型...], 返回值类型]

精确注解"函数参数"的类型，是框架/工具类开发必备

```python title="示例代码"
from typing import Callable  # 导入Callable类型用于表示可调用对象

def apply_func(func:  Callable[[int, int], int] , x: int, y: int) -> int:
    # 定义一个函数apply_func，接受一个可调用对象func和两个整数参数x和y，并返回一个整数
    return func(x, y)  # 调用传入的函数func，并将x和y作为参数传递给它，返回其结果
```


#### 容器类型注解 ❄️(list/dict/tuple/set）

标注列表、字典、元组、集合内部元素的类型

```python title="Python 3.9 以前（必须导入）"
# Python3.9以前，需要typing模块中的类型别名，如List、Dict、Tuple等
from typing import List, Dict, Tuple, Set
```


```python title="Python 3.9+（直接写，不用导入）"
list[int]
dict[str, int]
tuple[float, float]
set[str]
```


```python title="示例代码"
# 列表：里面全是int
nums : list[int]  = [1, 2, 3, 4]
# 字典：key是str，value是int
user_info: dict[str, int] = {"age": 18, "score": 95}
# 元组：第一个float，第二个float
point: tuple[float, float] = (11.2, 22.3)
# 集合：里面全是str
fruits: set[str] = {"apple", "banana"}
```


#### 复杂类型注解 ❄️

**可选类型**

```python title="可选类型（可能是值，也可能是None）"
str | None
int | None
# 等价于旧写法：Optional[str]
```


```python title="示例代码"
# 可选类型：返回str或None
# 旧版写法：
from typing import Optional  # 导入Optional类型用于表示可选值
def get_name(user_id: int) -> Optional[str]:
    return "Alice" if user_id == 1 else None

# 新版写法：
def get_name(user_id: int) -> str | None:
    if user_id == 1:
        return "Alice"
    else:
        return None

```


**联合类型**

```python title="联合类型（多种类型都可以）"
int | str
float | bool | str
# 等价于旧写法：Union[int, str]
```


```python title="示例代码"
# 联合类型：接受int或str
# 旧版写法：
from typing import Union
def print_data(data: Union[int, str]) -> None:
    print(data)
    
# 新版写法（Python 3.10+）：
def print_data(data: int | str) -> None:
    print(data)
```


**泛型**

如果函数或类可以适用于不同类型，但需要保证类型一致 **，** 用泛型Generic\[T]

```python title="使用 TypeVar 创建泛型类型"
from typing import  TypeVar, Generic   # 导入TypeVar和Generic用于定义泛型

T = TypeVar("T")  # 定义一个泛型类型变量T
# 定义一个泛型类Box，接受一个类型参数T
class Box( Generic[T] ):  
    def __init__(self,  content: T ):  # 定义构造函数，接受一个参数content，其类型为T
        self.content = content  # 将传入的内容存储在实例变量content中
        
box1: Box[int] = Box(10)  # 创建一个Box对象，指定内容类型为int，并初始化为10
box2: Box[str] = Box("hello")  # 创建一个Box对象，指定内容类型为str，并初始化为"hello"
```


让函数更灵活，同时保持类型安全

#### 自定义类型

自定义类型有比较高的灵活性

**字典结构约束**

让字典像类一样有固定结构，大幅提升接口数据安全性

```python title="示例"
from typing import  TypedDict 

# 定义一个TypedDict类，用于指定字典的键及其对应的值类型
class User(TypedDict):
    name: str    # name 键对应的是字符串类型
    age: int     # age 键对应的是整数类型
    
# 字典必须有name(str)和age(int)
user : User  = {
    "name": "Alice",  # 字典中name键的值为字符串"Alice"
    "age": 25         # 字典中age键的值为整数25
}
```


**创建别名类型**

```python title="示例"
from typing import  NewType 

# 使用NewType定义一个新的类型UserID，它是int类型的子类型
UserID =  NewType ("UserID", int)

# 定义一个函数get_user，接受一个UserID类型的参数并返回一个字符串
def get_user(user_id : UserID ) -> str:
    # 返回格式化的字符串，包含传入的user_id
    return f"User {user_id}"
# 创建一个UserID实例，值为1001
uid = UserID(1001)
# 调用get_user函数，并打印其返回值
print(get_user(uid))    # 输出：User 1001
```


#### Any与NoReturn

爱啥啥 和 啥也没

```python title="任何类型"
from typing import Any

def process(data : Any ) -> None:
    print(data)
```


```python title="不返回值"
from typing import NoReturn

def fatal_error(message: str) ->  NoReturn :
    raise RuntimeError(message)
    # 之后的代码不再执行
```


### ⭐ 静态类型检查（mypy）

静态类型检查：在代码运行前(编译阶段或执行前)分析代码中的类型注解，验证类型的一致性，提前发现潜在的类型错误

与动态类型的区别：Python是动态类型语言(运行时才检查类型)，而静态类型检查通过注解在编译期发现问题

**mypy**是Python最流行的静态类型检查工具，需单独安装

1. 根据函数/变量的类型注解进行检查
2. 若无注解，mypy默认按Any类型处理(不检查类型)

```bash title="安装 mypy"
pip install mypy
```


```python title="检查命令"
mypy 你的文件.py    # 检查单个Python文件
mypy 文件夹名/      # 递归检查目录下所有Python文件
```


![](image/image_JtkVz-vzF3.png)

**使用示例**

```python title="假设有以下代码（test.py）"
def add(x: int, y: int) -> int:
    return x + y
result = add("2", 3)  # 错误：字符串不能作为int类型参数
```


![](image/image_kewmiLZiPx.png)

—— 心情好的小球藻著🍀 ——

![  ](image/xqz_yI4B0gYMtW.png.mark.png "  ")
